import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const gold = Color(0xFFB58A32);
const ink = Color(0xFF2B251B);
const driveScope = 'https://www.googleapis.com/auth/drive.appdata';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const QuptanApp());
}

class QuptanApp extends StatelessWidget {
  const QuptanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'القبطان برو',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: const Color(0xFFFFFEFB),
      colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.light),
      appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: ink, elevation: 0),
    ),
    home: const ProfileGate(),
  );
}

class ProfileGate extends StatefulWidget {
  const ProfileGate({super.key});
  @override State<ProfileGate> createState() => _ProfileGateState();
}

class _ProfileGateState extends State<ProfileGate> {
  static const secure = FlutterSecureStorage();
  final name = TextEditingController();
  final pin = TextEditingController();
  final auth = LocalAuthentication();
  List<String> profiles = [];
  String? selected;
  bool setup = false, busy = false, biometricAvailable = false;
  String error = '';

  String _hash(String p, String salt) => sha256.convert(utf8.encode('$salt:$p')).toString();

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList('quptan_profiles') ?? [];
    bool bio = false;
    try { bio = await auth.canCheckBiometrics && await auth.isDeviceSupported(); } catch (_) {}
    if (!mounted) return;
    setState(() { profiles = list; biometricAvailable = bio; });
  }

  Future<void> _create() async {
    final n = name.text.trim(), p = pin.text.trim();
    if (n.isEmpty || p.length < 4 || p.length > 8 || int.tryParse(p) == null) {
      setState(() => error = 'اكتب اسم مستخدم ورقم PIN من 4 إلى 8 أرقام'); return;
    }
    setState(() { busy = true; error = ''; });
    final salt = List.generate(16, (_) => Random.secure().nextInt(256).toRadixString(16).padLeft(2,'0')).join();
    await secure.write(key: 'pin_$n', value: _hash(p, salt));
    await secure.write(key: 'salt_$n', value: salt);
    final prefs = await SharedPreferences.getInstance();
    profiles.add(n); await prefs.setStringList('quptan_profiles', profiles);
    if (!mounted) return;
    setState(() { busy = false; setup = false; selected = n; });
  }

  Future<void> _unlock() async {
    final n = selected, p = pin.text.trim();
    if (n == null) return;
    setState(() { busy = true; error = ''; });
    final salt = await secure.read(key: 'salt_$n') ?? '';
    final expected = await secure.read(key: 'pin_$n') ?? '';
    if (_hash(p, salt) != expected) {
      setState(() { busy = false; error = 'رقم PIN غير صحيح'; }); return;
    }
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => QuptanWebViewPage(profileId: n)));
  }

  Future<void> _bioUnlock() async {
    try {
      final ok = await auth.authenticate(localizedReason: 'تأكيد هويتك لفتح القبطان برو');
      if (ok && selected != null && mounted) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => QuptanWebViewPage(profileId: selected!)));
      }
    } catch (_) { setState(() => error = 'تعذر استخدام البصمة على هذا الجهاز'); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420), child: Column(
        mainAxisSize: MainAxisSize.min, children: [
          Container(width: 82,height:82,decoration: BoxDecoration(color: const Color(0xFFFFF8E8),border: Border.all(color: gold,width: 2),shape: BoxShape.circle),child: const Icon(Icons.workspace_premium,color: gold,size: 48)),
          const SizedBox(height: 14), const Text('القبطان برو',style: TextStyle(fontSize: 26,fontWeight: FontWeight.bold,color: ink)),
          const Text('حساب مستقل لكل مستخدم',style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 24),
          if (setup) ...[
            TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم المستخدم',border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: pin, keyboardType: TextInputType.number, obscureText: true, maxLength: 8, decoration: const InputDecoration(labelText: 'إنشاء PIN (4 إلى 8 أرقام)',border: OutlineInputBorder())),
            FilledButton(onPressed: busy ? null : _create, child: const Text('إنشاء الحساب')),
            TextButton(onPressed: () => setState(() => setup = false), child: const Text('رجوع')),
          ] else if (selected == null) ...[
            if (profiles.isNotEmpty) ...[
              const Text('اختر حسابك',style: TextStyle(fontWeight: FontWeight.bold)),
              for (final n in profiles) ListTile(leading: const Icon(Icons.person_outline,color: gold),title: Text(n),onTap: () => setState(() { selected = n; pin.clear(); })),
            ],
            OutlinedButton.icon(onPressed: () => setState(() => setup = true),icon: const Icon(Icons.person_add_alt_1),label: const Text('إنشاء مستخدم جديد')),
          ] else ...[
            Row(mainAxisAlignment: MainAxisAlignment.center,children:[Text('مرحبًا ${selected!}',style: const TextStyle(fontWeight: FontWeight.bold)),IconButton(onPressed:()=>setState(()=>selected=null),icon:const Icon(Icons.swap_horiz))]),
            TextField(controller: pin, keyboardType: TextInputType.number, obscureText: true, maxLength: 8, decoration: const InputDecoration(labelText: 'رقم PIN',border: OutlineInputBorder()),onSubmitted: (_) => _unlock()),
            FilledButton(onPressed: busy ? null : _unlock, child: const Text('فتح التطبيق')),
            if (biometricAvailable) TextButton.icon(onPressed: _bioUnlock, icon: const Icon(Icons.fingerprint), label: const Text('فتح بالبصمة')),
          ],
          if (error.isNotEmpty) Padding(padding: const EdgeInsets.only(top:12),child:Text(error,style:const TextStyle(color:Colors.red))),
        ],
      )),
    ))),
  );
}

class QuptanWebViewPage extends StatefulWidget {
  final String profileId;
  const QuptanWebViewPage({super.key, required this.profileId});
  @override State<QuptanWebViewPage> createState() => _QuptanWebViewPageState();
}

class _QuptanWebViewPageState extends State<QuptanWebViewPage> {
  late final WebViewController controller;
  bool loading = true, profileInjected = false;
  Timer? autoBackupTimer;
  String? error;
  final GoogleSignIn google = GoogleSignIn(scopes: [driveScope]);

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('QuptanBridge', onMessageReceived: _onBridge)
      ..setBackgroundColor(Colors.white)
      ..enableZoom(false)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) { if(mounted) setState(()=>loading=true); },
        onPageFinished: (_) async {
          if (!profileInjected) {
            profileInjected = true;
            await controller.runJavaScript("localStorage.setItem('quptan_active_profile', ${jsonEncode(widget.profileId)}); location.reload();");
            return;
          }
          if(mounted) setState(()=>loading=false);
          autoBackupTimer ??= Timer.periodic(const Duration(hours: 24), (_) { controller.runJavaScript('window.quptanCloudAutoBackup && window.quptanCloudAutoBackup();'); });
        },
        onWebResourceError: (e) { if(e.isForMainFrame==true&&mounted){setState(() { loading=false; error=e.description; });} },
        onNavigationRequest: (r) {
          final u=Uri.tryParse(r.url); if(u==null)return NavigationDecision.prevent;
          if(u.scheme=='http'||u.scheme=='https'||u.scheme=='tel'||u.scheme=='mailto'||u.scheme=='whatsapp'){
            unawaited(launchUrl(u,mode:LaunchMode.externalApplication)); return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ))
      ..loadFlutterAsset('assets/index.html');
  }

  Future<void> _onBridge(JavaScriptMessage message) async {
    try {
      final data=jsonDecode(message.message) as Map<String,dynamic>;
      if(data['action']=='backup') await _backup(data['payload']?.toString() ?? '', allowSignIn: true);
      if(data['action']=='backup_auto') await _backup(data['payload']?.toString() ?? '', allowSignIn: false);
      if(data['action']=='restore') await _restore();
    } catch(e) { _toast('تعذر تنفيذ العملية: $e'); }
  }

  Future<String?> _accessToken({bool allowSignIn = true}) async {
    final linkedEmail = await const FlutterSecureStorage().read(key: 'drive_email_${widget.profileId}');
    GoogleSignInAccount? account = google.currentUser;
    account ??= await google.signInSilently();

    // A new local profile must explicitly choose its own Google account.
    if (linkedEmail == null) {
      if (!allowSignIn) return null;
      await google.signOut();
      account = await google.signIn();
    } else if (account != null && account.email.toLowerCase() != linkedEmail.toLowerCase()) {
      await google.signOut();
      account = null;
    }

    if (account == null && allowSignIn) account = await google.signIn();
    if (account == null) return null;
    await const FlutterSecureStorage().write(key: 'drive_email_${widget.profileId}', value: account.email);
    final auth = await account.authentication;
    return auth.accessToken;
  }

  Future<void> _backup(String payload, {required bool allowSignIn}) async {
    if(payload.isEmpty) { _toast('لا توجد بيانات لنسخها'); return; }
    final token=await _accessToken(allowSignIn: allowSignIn); if(token==null) { if(allowSignIn) _toast('لم يتم ربط Google Drive بعد'); return; }
    final headers={'Authorization':'Bearer $token','Content-Type':'application/json'};
    final list=await http.get(Uri.parse('https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name%3D%27quptan-${Uri.encodeComponent(widget.profileId)}.json%27&fields=files(id,name)&pageSize=1'),headers:headers);
    if(list.statusCode!=200) throw Exception('Drive list ${list.statusCode}');
    final files=(jsonDecode(list.body)['files'] as List).cast<Map<String,dynamic>>();
    final bytes=utf8.encode(jsonEncode({'profile':widget.profileId,'updatedAt':DateTime.now().toIso8601String(),'data':jsonDecode(payload)}));
    if(files.isEmpty) {
      final meta=await http.post(Uri.parse('https://www.googleapis.com/drive/v3/files'),headers:headers,body:jsonEncode({'name':'quptan-${widget.profileId}.json','parents':['appDataFolder']}));
      if(meta.statusCode!=200) throw Exception('Drive create ${meta.statusCode}');
      final id=jsonDecode(meta.body)['id'];
      final upload=await http.patch(Uri.parse('https://www.googleapis.com/upload/drive/v3/files/$id?uploadType=media'),headers:{'Authorization':'Bearer $token','Content-Type':'application/json'},body:bytes);
      if(upload.statusCode!=200) throw Exception('Drive upload ${upload.statusCode}');
    } else {
      final id=files.first['id'];
      final upload=await http.patch(Uri.parse('https://www.googleapis.com/upload/drive/v3/files/$id?uploadType=media'),headers:{'Authorization':'Bearer $token','Content-Type':'application/json'},body:bytes);
      if(upload.statusCode!=200) throw Exception('Drive update ${upload.statusCode}');
    }
    _toast('تم حفظ النسخة الاحتياطية على Google Drive');
  }

  Future<void> _restore() async {
    final token=await _accessToken(allowSignIn: true); if(token==null)return;
    final headers={'Authorization':'Bearer $token'};
    final list=await http.get(Uri.parse('https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name%3D%27quptan-${Uri.encodeComponent(widget.profileId)}.json%27&fields=files(id,name)&pageSize=1'),headers:headers);
    if(list.statusCode!=200)throw Exception('Drive list ${list.statusCode}');
    final files=(jsonDecode(list.body)['files'] as List).cast<Map<String,dynamic>>();
    if(files.isEmpty){_toast('لا توجد نسخة لهذا المستخدم');return;}
    final id=files.first['id'];
    final download=await http.get(Uri.parse('https://www.googleapis.com/drive/v3/files/$id?alt=media'),headers:headers);
    if(download.statusCode!=200)throw Exception('Drive download ${download.statusCode}');
    final backup=jsonDecode(download.body) as Map<String,dynamic>;
    if(backup['profile']!=widget.profileId)throw Exception('النسخة لا تخص هذا المستخدم');
    final encoded=jsonEncode(backup['data']);
    await controller.runJavaScript("window.applyQuptanCloudBackup(${jsonEncode(encoded)});");
    _toast('تمت استعادة النسخة الاحتياطية');
  }

  void _toast(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
  @override void dispose(){ autoBackupTimer?.cancel(); super.dispose(); }
  @override Widget build(BuildContext context)=>PopScope(
    canPop:false,
    onPopInvokedWithResult:(didPop,result)async{if(!didPop){if(await controller.canGoBack()){await controller.goBack();}else{await SystemNavigator.pop();}}},
    child:Scaffold(body:SafeArea(child:Stack(children:[
      WebViewWidget(controller:controller),
      if(loading)const Align(alignment:Alignment.topCenter,child:LinearProgressIndicator(minHeight:2,color:gold,backgroundColor:Color(0xFFFFF4D8))),
      if(error!=null)Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.error_outline,color:gold,size:42),Text('تعذر فتح واجهة القبطان'),Text(error!),ElevatedButton(onPressed:()=>controller.loadFlutterAsset('assets/index.html'),child:const Text('إعادة المحاولة'))]))),
    ]))),
  );
}
