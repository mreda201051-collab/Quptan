import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:excel/excel.dart';
import 'package:webview_flutter/webview_flutter.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  runApp(const QuptanApp());
}

class QuptanApp extends StatelessWidget {
  const QuptanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'QUPTAN WE EGYPT PRO', debugShowCheckedModeBanner: false,
    theme: ThemeData.dark().copyWith(scaffoldBackgroundColor: const Color(0xFF0B0A10)),
    home: const ProgramScreen(),
  );
}

class ProgramScreen extends StatefulWidget {
  const ProgramScreen({super.key});
  @override
  State<ProgramScreen> createState() => _ProgramScreenState();
}

class _ProgramScreenState extends State<ProgramScreen> {
  late final WebViewController controller;
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0B0A10))
      ..addJavaScriptChannel('QuptanBridge', onMessageReceived: _onBridgeMessage)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) => setState(() { loading = true; error = null; }),
        onPageFinished: (_) => setState(() => loading = false),
        onWebResourceError: (e) { if (e.isForMainFrame ?? false) setState(() { loading = false; error = e.description; }); },
        onNavigationRequest: (r) => r.url.startsWith('file:') || r.url.startsWith('about:') || r.url.startsWith('https://') ? NavigationDecision.navigate : NavigationDecision.prevent,
      ))
      ..loadFlutterAsset('assets/index.html');
  }

  Future<void> _onBridgeMessage(JavaScriptMessage message) async {
    try {
      final m = jsonDecode(message.message) as Map<String, dynamic>;
      if (m['action'] == 'backup') {
        final dir = await getTemporaryDirectory();
        final file = File('${dir.path}/${m['name']}');
        await file.writeAsString(m['data'] as String, flush: true);
        await Share.shareXFiles([XFile(file.path, mimeType: 'application/json')], text: 'نسخة احتياطية من برنامج القبطان. يمكنك حفظها في Google Drive.');
      } else if (m['action'] == 'excel') {
        await _exportExcel(m['data'] as Map<String, dynamic>);
      } else if (m['action'] == 'restore') {
        final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json'], withData: true);
        if (result == null || result.files.single.bytes == null) return;
        final raw = utf8.decode(result.files.single.bytes!);
        final encoded = base64Encode(utf8.encode(raw));
        await controller.runJavaScript("importBackupJson(utf8DecodeBase64('$encoded'));");
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تنفيذ العملية: $e')));
    }
  }

  Future<void> _exportExcel(Map<String, dynamic> db) async {
    final book = Excel.createExcel();
    book.rename('Sheet1', 'المبيعات');
    void addSheet(String name, List<String> headers, List<List<dynamic>> rows) {
      final sheet = book[name];
      sheet.appendRow(headers.map((v) => TextCellValue(v)).toList());
      for (final row in rows) {
        sheet.appendRow(row.map((v) => TextCellValue(v?.toString() ?? '')).toList());
      }
    }
    final sales = (db['sales'] as List? ?? []).cast<Map>();
    final packages = (db['packages'] as List? ?? []).cast<Map>();
    final lines = (db['mainLines'] as List? ?? []).cast<Map>();
    final expenses = (db['expenses'] as List? ?? []).cast<Map>();
    String pkg(dynamic id) => packages.where((p) => p['id'] == id).map((p) => p['name']?.toString() ?? '').firstOrNull ?? '';
    String line(dynamic id) => lines.where((p) => p['id'] == id).map((p) => p['name']?.toString() ?? '').firstOrNull ?? '';
    addSheet('المبيعات', ['رقم العملية','اسم العميل','الهاتف','الباقة','الخط الأم','الجيجا','تاريخ التفعيل','السعر النهائي','التكلفة','المدفوع','المتبقي','ملاحظات'], sales.map((s) => [s['id'],s['name'],s['phone'],pkg(s['packageId']),line(s['lineId']),s['gb'],s['activation'] ?? s['date'],s['price'],s['cost'],((s['payments'] as List? ?? []).fold<num>(0,(a,p)=>a+((p as Map)['amount'] as num? ?? 0))),((s['price'] as num? ?? 0)-((s['payments'] as List? ?? []).fold<num>(0,(a,p)=>a+((p as Map)['amount'] as num? ?? 0)))).clamp(0,double.infinity),s['notes']]).toList());
    final payments = <List<dynamic>>[];
    for (final s in sales) { var i=0; for(final p in (s['payments'] as List? ?? [])) { i++; payments.add([s['id'],s['name'],s['phone'],i,(p as Map)['amount'],p['date'],p['method']]); } }
    addSheet('سجل التحصيلات',['رقم العملية','العميل','الهاتف','رقم الدفعة','المبلغ','التاريخ','طريقة الدفع'],payments);
    addSheet('الخطوط الأساسية',['اسم الخط','تاريخ الشحن','إجمالي الجيجا','إجمالي الدقائق','التكلفة','ملاحظات'],lines.map((l)=>[l['name'],l['date'],l['totalGb'],l['totalMinutes'],l['cost'],l['notes']]).toList());
    addSheet('المصروفات',['الكود','التاريخ','البيان','الكمية','الجيجات','المبلغ','ملاحظات'],expenses.map((e)=>[e['code'],e['date'],e['description'],e['quantity'],e['gb'],e['amount'],e['notes']]).toList());
    final bytes = book.encode();
    if (bytes == null) throw Exception('تعذر إنشاء ملف Excel');
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/AlQuptan_Packages_${DateTime.now().toIso8601String().substring(0,10)}.xlsx');
    await file.writeAsBytes(bytes, flush: true);
    await Share.shareXFiles([XFile(file.path, mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')], text: 'تقرير Excel من برنامج القبطان');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Stack(children: [
      WebViewWidget(controller: controller),
      if (loading) const Center(child: CircularProgressIndicator(color: Color(0xFFD7B45A))),
      if (error != null) Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.error_outline, color: Colors.red, size: 42), const SizedBox(height: 12), Text('تعذر فتح البرنامج: $error', textAlign: TextAlign.center), const SizedBox(height: 12), ElevatedButton(onPressed: () => controller.reload(), child: const Text('إعادة المحاولة'))]))),
    ])),
  );
}
