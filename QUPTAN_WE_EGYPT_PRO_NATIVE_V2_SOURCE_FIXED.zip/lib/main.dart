import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/drive/v3.dart' as drive;
import 'package:http/http.dart' as http;

const navy = Color(0xFF071426);
const navy2 = Color(0xFF102744);
const gold = Color(0xFFE7BD58);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppStore.instance.init();
  runApp(const QuptanApp());
}

class AppStore {
  AppStore._();
  static final AppStore instance = AppStore._();
  late Database db;
  late SharedPreferences prefs;

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    final root = await getDatabasesPath();
    db = await openDatabase(
      p.join(root, 'quptan_pro.db'),
      version: 1,
      onCreate: (database, version) async {
        await database.execute('''
          CREATE TABLE records(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module TEXT NOT NULL,
            title TEXT NOT NULL,
            phone TEXT DEFAULT '',
            packageName TEXT DEFAULT '',
            amount REAL DEFAULT 0,
            paid REAL DEFAULT 0,
            dueDate TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            createdAt TEXT NOT NULL
          )
        ''');
        await database.execute(
          'CREATE INDEX records_module_idx ON records(module)',
        );
      },
    );
  }

  Future<List<Map<String, dynamic>>> list(String module) => db.query(
        'records',
        where: 'module = ?',
        whereArgs: [module],
        orderBy: 'id DESC',
      );

  Future<void> save(Map<String, dynamic> row) async {
    if (row['id'] == null) {
      row['createdAt'] = DateTime.now().toIso8601String();
      await db.insert('records', row);
    } else {
      await db.update('records', row, where: 'id = ?', whereArgs: [row['id']]);
    }
  }

  Future<void> delete(int id) =>
      db.delete('records', where: 'id = ?', whereArgs: [id]);

  Future<Map<String, dynamic>> exportAll() async => {
        'schema': 1,
        'app': 'QUPTAN WE EGYPT PRO',
        'exportedAt': DateTime.now().toIso8601String(),
        'records': await db.query('records'),
        'settings': {
          'language': prefs.getString('language') ?? 'ar',
          'theme': prefs.getString('theme') ?? 'dark',
          'cycleStartDay': prefs.getInt('cycleStartDay') ?? 16,
          'autoBackup': prefs.getBool('autoBackup') ?? false,
        },
      };

  Future<void> importAll(Map<String, dynamic> data) async {
    if (data['app'] != 'QUPTAN WE EGYPT PRO' ||
        data['schema'] != 1 ||
        data['records'] is! List) {
      throw const FormatException('Invalid QUPTAN backup');
    }
    await db.transaction((txn) async {
      await txn.delete('records');
      for (final item in data['records'] as List) {
        final row = Map<String, dynamic>.from(item as Map);
        row.remove('id');
        await txn.insert('records', row);
      }
    });
    final settings = Map<String, dynamic>.from(data['settings'] as Map? ?? {});
    if (settings['language'] is String) {
      await prefs.setString('language', settings['language'] as String);
    }
    if (settings['theme'] is String) {
      await prefs.setString('theme', settings['theme'] as String);
    }
    if (settings['cycleStartDay'] is int) {
      await prefs.setInt('cycleStartDay', settings['cycleStartDay'] as int);
    }
    if (settings['autoBackup'] is bool) {
      await prefs.setBool('autoBackup', settings['autoBackup'] as bool);
    }
  }
}

class QuptanApp extends StatefulWidget {
  const QuptanApp({super.key});
  @override
  State<QuptanApp> createState() => _QuptanAppState();
}

class _QuptanAppState extends State<QuptanApp> {
  String language = 'ar';
  String appearance = 'dark';

  @override
  void initState() {
    super.initState();
    language = AppStore.instance.prefs.getString('language') ?? 'ar';
    appearance = AppStore.instance.prefs.getString('theme') ?? 'dark';
  }

  void updatePrefs({String? language, String? appearance}) {
    setState(() {
      if (language != null) this.language = language;
      if (appearance != null) this.appearance = appearance;
    });
    if (language != null) AppStore.instance.prefs.setString('language', language);
    if (appearance != null) AppStore.instance.prefs.setString('theme', appearance);
  }

  @override
  Widget build(BuildContext context) {
    final dark = appearance == 'dark';
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'QUPTAN WE EGYPT PRO',
      theme: ThemeData(
        useMaterial3: true,
        brightness: dark ? Brightness.dark : Brightness.light,
        scaffoldBackgroundColor: dark ? navy : const Color(0xFFF4F6FA),
        colorScheme: ColorScheme.fromSeed(
          seedColor: gold,
          brightness: dark ? Brightness.dark : Brightness.light,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: dark ? navy : Colors.white,
          foregroundColor: dark ? Colors.white : navy,
        ),
      ),
      home: HomeShell(
        language: language,
        dark: dark,
        onPrefs: updatePrefs,
      ),
    );
  }
}

class T {
  static const Map<String, Map<String, String>> data = {
    'ar': {
      'app': 'القبطان برو', 'home': 'الرئيسية', 'customers': 'العملاء',
      'bookings': 'الحجوزات', 'more': 'المزيد', 'sales': 'المبيعات',
      'payments': 'التحصيلات', 'expenses': 'المصروفات',
      'packages': 'الباقات الأساسية', 'reports': 'التقارير',
      'settings': 'الإعدادات', 'backup': 'النسخ الاحتياطي',
      'totalSales': 'إجمالي المبيعات', 'totalPaid': 'إجمالي المحصل',
      'remaining': 'المتبقي', 'latest': 'آخر 5 مبيعات', 'add': 'إضافة جديد',
      'edit': 'تعديل', 'delete': 'حذف', 'cancel': 'إلغاء', 'save': 'حفظ',
      'name': 'الاسم', 'phone': 'رقم الهاتف', 'package': 'الباقة',
      'amount': 'الإجمالي', 'paid': 'المدفوع', 'date': 'التاريخ',
      'notes': 'ملاحظات', 'noData': 'لا توجد بيانات حتى الآن',
      'confirmDelete': 'هل تريد حذف هذا السجل؟', 'language': 'اللغة',
      'arabic': 'العربية', 'english': 'English', 'appearance': 'المظهر',
      'dark': 'داكن', 'light': 'فاتح', 'cycle': 'بداية دورة الحساب',
      'driveBackup': 'Google Drive', 'createBackup': 'إنشاء نسخة احتياطية',
      'restoreBackup': 'استعادة من ملف', 'connectGoogle': 'ربط حساب Google',
      'backupNow': 'نسخ احتياطي الآن', 'restoreDrive': 'استعادة من Google Drive',
      'notConnected': 'حساب Google غير مرتبط', 'success': 'تم بنجاح',
      'search': 'بحث', 'call': 'اتصال', 'whatsapp': 'واتساب',
      'dashboard': 'ملخص النشاط', 'chooseRestore': 'سيتم استبدال البيانات الحالية. هل تريد المتابعة؟',
      'yes': 'متابعة', 'cycleHint': 'يُحسب تاريخ نهاية الدورة تلقائيًا حسب الشهر',
      'autoBackup': 'نسخ احتياطي تلقائي عند فتح التطبيق',
    },
    'en': {
      'app': 'QUPTAN PRO', 'home': 'Home', 'customers': 'Customers',
      'bookings': 'Bookings', 'more': 'More', 'sales': 'Sales',
      'payments': 'Collections', 'expenses': 'Expenses', 'packages': 'Base packages',
      'reports': 'Reports', 'settings': 'Settings', 'backup': 'Backup & restore',
      'totalSales': 'Total sales', 'totalPaid': 'Total collected', 'remaining': 'Remaining',
      'latest': 'Latest 5 sales', 'add': 'Add new', 'edit': 'Edit', 'delete': 'Delete',
      'cancel': 'Cancel', 'save': 'Save', 'name': 'Name', 'phone': 'Phone number',
      'package': 'Package', 'amount': 'Total', 'paid': 'Paid', 'date': 'Date',
      'notes': 'Notes', 'noData': 'No records yet', 'confirmDelete': 'Delete this record?',
      'language': 'Language', 'arabic': 'العربية', 'english': 'English',
      'appearance': 'Appearance', 'dark': 'Dark', 'light': 'Light',
      'cycle': 'Accounting cycle start day', 'driveBackup': 'Google Drive',
      'createBackup': 'Create backup file', 'restoreBackup': 'Restore from file',
      'connectGoogle': 'Connect Google account', 'backupNow': 'Back up now',
      'restoreDrive': 'Restore from Google Drive', 'notConnected': 'Google account not connected',
      'success': 'Completed', 'search': 'Search', 'call': 'Call', 'whatsapp': 'WhatsApp',
      'dashboard': 'Activity summary', 'chooseRestore': 'Current data will be replaced. Continue?',
      'yes': 'Continue', 'cycleHint': 'The cycle end date is calculated automatically.',
      'autoBackup': 'Automatic backup when app opens',
    },
  };

  static String s(String language, String key) =>
      data[language]?[key] ?? data['en']![key] ?? key;
}

class Module {
  final String key;
  final String title;
  final IconData icon;
  const Module(this.key, this.title, this.icon);
}

const modules = <Module>[
  Module('sales', 'sales', Icons.point_of_sale),
  Module('customers', 'customers', Icons.people_alt),
  Module('bookings', 'bookings', Icons.event_note),
  Module('payments', 'payments', Icons.account_balance_wallet),
  Module('expenses', 'expenses', Icons.receipt_long),
  Module('packages', 'packages', Icons.inventory_2),
];

class HomeShell extends StatefulWidget {
  final String language;
  final bool dark;
  final void Function({String? language, String? appearance}) onPrefs;
  const HomeShell({super.key, required this.language, required this.dark, required this.onPrefs});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      Dashboard(language: widget.language),
      ModulePage(module: modules[1], language: widget.language),
      ModulePage(module: modules[2], language: widget.language),
      MorePage(language: widget.language, onPrefs: widget.onPrefs),
    ];
    return Directionality(
      textDirection: widget.language == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        body: SafeArea(child: pages[index]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (value) => setState(() => index = value),
          backgroundColor: widget.dark ? navy2 : Colors.white,
          indicatorColor: const Color.fromRGBO(231, 189, 88, .22),
          destinations: [
            NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: T.s(widget.language, 'home')),
            NavigationDestination(icon: const Icon(Icons.people_outline), selectedIcon: const Icon(Icons.people), label: T.s(widget.language, 'customers')),
            NavigationDestination(icon: const Icon(Icons.event_note_outlined), selectedIcon: const Icon(Icons.event_note), label: T.s(widget.language, 'bookings')),
            NavigationDestination(icon: const Icon(Icons.grid_view), selectedIcon: const Icon(Icons.grid_view_rounded), label: T.s(widget.language, 'more')),
          ],
        ),
      ),
    );
  }
}

class Dashboard extends StatefulWidget {
  final String language;
  const Dashboard({super.key, required this.language});
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  bool expanded = false;
  List<Map<String, dynamic>> sales = [];
  List<Map<String, dynamic>> all = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final records = <Map<String, dynamic>>[];
    for (final module in modules) {
      records.addAll(await AppStore.instance.list(module.key));
    }
    final latestSales = await AppStore.instance.list('sales');
    if (!mounted) return;
    setState(() {
      all = records;
      sales = latestSales;
    });
  }

  double sum(String key) => all.fold<double>(
        0,
        (total, row) => total + ((row[key] as num?)?.toDouble() ?? 0),
      );

  Widget stat(String title, double value, IconData icon) => SizedBox(
        width: (MediaQuery.of(context).size.width - 42) / 2,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(13),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(icon, color: gold),
              const SizedBox(height: 8),
              Text(title, style: const TextStyle(fontSize: 12)),
              Text(value.toStringAsFixed(2), style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final language = widget.language;
    return RefreshIndicator(
      onRefresh: load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            const Icon(Icons.explore, color: gold, size: 30),
            const SizedBox(width: 10),
            Expanded(child: Text(T.s(language, 'app'), style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold))),
            IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
          ]),
          const SizedBox(height: 18),
          Text(T.s(language, 'dashboard'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Wrap(spacing: 10, runSpacing: 10, children: [
            stat(T.s(language, 'totalSales'), sum('amount'), Icons.trending_up),
            stat(T.s(language, 'totalPaid'), sum('paid'), Icons.payments),
            stat(T.s(language, 'remaining'), sum('amount') - sum('paid'), Icons.account_balance_wallet),
          ]),
          const SizedBox(height: 20),
          Text(T.s(language, 'latest'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
          Card(child: Column(children: [
            ListTile(
              title: Text(T.s(language, 'latest')),
              trailing: IconButton(
                onPressed: () => setState(() => expanded = !expanded),
                icon: Icon(expanded ? Icons.expand_less : Icons.expand_more),
              ),
            ),
            if (expanded)
              ...sales.take(5).map((row) => ListTile(
                    dense: true,
                    title: Text('${row['title']}'),
                    subtitle: Text('${row['createdAt']}'.split('T').first),
                    trailing: Text('${row['amount'] ?? 0}'),
                  )),
            if (expanded && sales.isEmpty)
              Padding(padding: const EdgeInsets.all(16), child: Text(T.s(language, 'noData'))),
          ])),
          const SizedBox(height: 20),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            childAspectRatio: 1.7,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            children: modules.map((module) => Card(
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => ModulePage(module: module, language: language),
                )),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(module.icon, color: gold, size: 27),
                      const SizedBox(height: 8),
                      Text(T.s(language, module.title), style: const TextStyle(fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ),
            )).toList(),
          ),
        ],
      ),
    );
  }
}

class ModulePage extends StatefulWidget {
  final Module module;
  final String language;
  const ModulePage({super.key, required this.module, required this.language});
  @override
  State<ModulePage> createState() => _ModulePageState();
}

class _ModulePageState extends State<ModulePage> {
  List<Map<String, dynamic>> rows = [];
  String query = '';

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final result = await AppStore.instance.list(widget.module.key);
    if (!mounted) return;
    setState(() => rows = result);
  }

  Future<void> edit([Map<String, dynamic>? row]) async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => RecordDialog(language: widget.language, initial: row),
    );
    if (result == null) return;
    if (row != null) result['id'] = row['id'];
    result['module'] = widget.module.key;
    await AppStore.instance.save(result);
    await load();
  }

  Future<void> handleMenu(String value, Map<String, dynamic> row) async {
    if (value == 'edit') {
      await edit(row);
      return;
    }
    if (value == 'call' || value == 'whatsapp') {
      final raw = '${row['phone'] ?? ''}'.replaceAll(RegExp(r'[^0-9+]'), '');
      if (raw.isEmpty) return;
      final uri = value == 'call'
          ? Uri(scheme: 'tel', path: raw)
          : Uri.parse('https://wa.me/${raw.replaceAll('+', '')}');
      await launchUrl(uri, mode: LaunchMode.externalApplication);
      return;
    }
    if (value == 'delete') {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: Text(T.s(widget.language, 'delete')),
          content: Text(T.s(widget.language, 'confirmDelete')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: Text(T.s(widget.language, 'cancel'))),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(T.s(widget.language, 'delete'))),
          ],
        ),
      );
      if (confirmed == true) {
        await AppStore.instance.delete(row['id'] as int);
        await load();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final language = widget.language;
    final filtered = rows.where((row) =>
      '${row['title']} ${row['phone']} ${row['packageName']}'.toLowerCase().contains(query.toLowerCase())
    ).toList();
    return Scaffold(
      appBar: AppBar(
        title: Text(T.s(language, widget.module.title)),
        actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: gold,
        foregroundColor: navy,
        onPressed: () => edit(),
        icon: const Icon(Icons.add),
        label: Text(T.s(language, 'add')),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            onChanged: (value) => setState(() => query = value),
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: T.s(language, 'search'),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ),
        Expanded(
          child: filtered.isEmpty
              ? Center(child: Text(T.s(language, 'noData')))
              : ListView.builder(
                  itemCount: filtered.length,
                  itemBuilder: (context, index) {
                    final row = filtered[index];
                    final amount = (row['amount'] as num?)?.toDouble() ?? 0;
                    final paid = (row['paid'] as num?)?.toDouble() ?? 0;
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      child: ListTile(
                        onTap: () => edit(row),
                        leading: CircleAvatar(
                          backgroundColor: const Color.fromRGBO(231, 189, 88, .18),
                          child: Icon(widget.module.icon, color: gold),
                        ),
                        title: Text('${row['title']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text([
                          '${row['phone'] ?? ''}',
                          '${row['packageName'] ?? ''}',
                          '${T.s(language, 'paid')}: $paid / $amount',
                          '${row['dueDate'] ?? ''}',
                        ].where((value) => value.trim().isNotEmpty).join('  •  ')),
                        trailing: PopupMenuButton<String>(
                          onSelected: (value) => handleMenu(value, row),
                          itemBuilder: (_) => [
                            PopupMenuItem(value: 'call', child: Text(T.s(language, 'call'))),
                            PopupMenuItem(value: 'whatsapp', child: Text(T.s(language, 'whatsapp'))),
                            PopupMenuItem(value: 'edit', child: Text(T.s(language, 'edit'))),
                            PopupMenuItem(value: 'delete', child: Text(T.s(language, 'delete'))),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

class RecordDialog extends StatefulWidget {
  final String language;
  final Map<String, dynamic>? initial;
  const RecordDialog({super.key, required this.language, this.initial});
  @override
  State<RecordDialog> createState() => _RecordDialogState();
}

class _RecordDialogState extends State<RecordDialog> {
  late final titleController = TextEditingController(text: '${widget.initial?['title'] ?? ''}');
  late final phoneController = TextEditingController(text: '${widget.initial?['phone'] ?? ''}');
  late final packageController = TextEditingController(text: '${widget.initial?['packageName'] ?? ''}');
  late final amountController = TextEditingController(text: '${widget.initial?['amount'] ?? ''}');
  late final paidController = TextEditingController(text: '${widget.initial?['paid'] ?? ''}');
  late final dateController = TextEditingController(text: '${widget.initial?['dueDate'] ?? ''}');
  late final notesController = TextEditingController(text: '${widget.initial?['notes'] ?? ''}');

  String label(String key) => T.s(widget.language, key);

  @override
  void dispose() {
    for (final controller in [titleController, phoneController, packageController, amountController, paidController, dateController, notesController]) {
      controller.dispose();
    }
    super.dispose();
  }

  Widget field(TextEditingController controller, String key, {TextInputType? keyboard, int lines = 1, String? hint}) => Padding(
        padding: const EdgeInsets.only(bottom: 9),
        child: TextField(
          controller: controller,
          keyboardType: keyboard,
          maxLines: lines,
          decoration: InputDecoration(labelText: label(key), hintText: hint, border: const OutlineInputBorder()),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(label(widget.initial == null ? 'add' : 'edit')),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            field(titleController, 'name'),
            field(phoneController, 'phone', keyboard: TextInputType.phone),
            field(packageController, 'package'),
            field(amountController, 'amount', keyboard: const TextInputType.numberWithOptions(decimal: true)),
            field(paidController, 'paid', keyboard: const TextInputType.numberWithOptions(decimal: true)),
            field(dateController, 'date', hint: 'YYYY-MM-DD'),
            field(notesController, 'notes', lines: 2),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text(label('cancel'))),
        FilledButton(
          onPressed: () {
            if (titleController.text.trim().isEmpty) return;
            Navigator.pop(context, {
              'title': titleController.text.trim(),
              'phone': phoneController.text.trim(),
              'packageName': packageController.text.trim(),
              'amount': double.tryParse(amountController.text) ?? 0,
              'paid': double.tryParse(paidController.text) ?? 0,
              'dueDate': dateController.text.trim(),
              'notes': notesController.text.trim(),
            });
          },
          child: Text(label('save')),
        ),
      ],
    );
  }
}

class MorePage extends StatelessWidget {
  final String language;
  final void Function({String? language, String? appearance}) onPrefs;
  const MorePage({super.key, required this.language, required this.onPrefs});

  @override
  Widget build(BuildContext context) {
    final items = [modules[0], modules[3], modules[4], modules[5]];
    return Scaffold(
      appBar: AppBar(title: Text(T.s(language, 'more'))),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          ...items.map((module) => Card(child: ListTile(
            leading: Icon(module.icon, color: gold),
            title: Text(T.s(language, module.title)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ModulePage(module: module, language: language))),
          ))),
          Card(child: ListTile(
            leading: const Icon(Icons.bar_chart, color: gold),
            title: Text(T.s(language, 'reports')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReportsPage(language: language))),
          )),
          Card(child: ListTile(
            leading: const Icon(Icons.cloud_sync, color: gold),
            title: Text(T.s(language, 'backup')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BackupPage(language: language))),
          )),
          Card(child: ListTile(
            leading: const Icon(Icons.settings, color: gold),
            title: Text(T.s(language, 'settings')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsPage(language: language, onPrefs: onPrefs))),
          )),
        ],
      ),
    );
  }
}

class ReportsPage extends StatefulWidget {
  final String language;
  const ReportsPage({super.key, required this.language});
  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  double sales = 0, paid = 0, expenses = 0;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final salesRows = await AppStore.instance.list('sales');
    final paymentRows = await AppStore.instance.list('payments');
    final expenseRows = await AppStore.instance.list('expenses');
    double total(List<Map<String, dynamic>> rows, String key) => rows.fold<double>(
      0, (sum, row) => sum + ((row[key] as num?)?.toDouble() ?? 0),
    );
    if (!mounted) return;
    setState(() {
      sales = total(salesRows, 'amount');
      paid = total(paymentRows, 'amount');
      expenses = total(expenseRows, 'amount');
    });
  }

  Widget tile(String title, double value) => Card(child: ListTile(
    title: Text(title),
    trailing: Text(value.toStringAsFixed(2), style: const TextStyle(fontWeight: FontWeight.bold, color: gold)),
  ));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(T.s(widget.language, 'reports'))),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      tile(T.s(widget.language, 'totalSales'), sales),
      tile(T.s(widget.language, 'totalPaid'), paid),
      tile(T.s(widget.language, 'expenses'), expenses),
      tile(T.s(widget.language, 'remaining'), sales - paid - expenses),
    ]),
  );
}

class SettingsPage extends StatefulWidget {
  final String language;
  final void Function({String? language, String? appearance}) onPrefs;
  const SettingsPage({super.key, required this.language, required this.onPrefs});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late int day = AppStore.instance.prefs.getInt('cycleStartDay') ?? 16;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(T.s(widget.language, 'settings'))),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Text(T.s(widget.language, 'language'), style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      SegmentedButton<String>(
        segments: [
          ButtonSegment(value: 'ar', label: Text(T.s(widget.language, 'arabic'))),
          ButtonSegment(value: 'en', label: Text(T.s(widget.language, 'english'))),
        ],
        selected: {widget.language},
        onSelectionChanged: (selection) {
          widget.onPrefs(language: selection.first);
          Navigator.pop(context);
        },
      ),
      const SizedBox(height: 20),
      Text(T.s(widget.language, 'appearance'), style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      SegmentedButton<String>(
        segments: [
          ButtonSegment(value: 'dark', label: Text(T.s(widget.language, 'dark'))),
          ButtonSegment(value: 'light', label: Text(T.s(widget.language, 'light'))),
        ],
        selected: {AppStore.instance.prefs.getString('theme') ?? 'dark'},
        onSelectionChanged: (selection) {
          widget.onPrefs(appearance: selection.first);
          Navigator.pop(context);
        },
      ),
      const SizedBox(height: 20),
      Text(T.s(widget.language, 'cycle'), style: const TextStyle(fontWeight: FontWeight.bold)),
      Slider(
        value: day.toDouble(), min: 1, max: 31, divisions: 30, label: '$day',
        onChanged: (value) => setState(() => day = value.round()),
        onChangeEnd: (value) => AppStore.instance.prefs.setInt('cycleStartDay', value.round()),
      ),
      Text('$day  •  ${T.s(widget.language, 'cycleHint')}'),
    ]),
  );
}

class BackupPage extends StatefulWidget {
  final String language;
  const BackupPage({super.key, required this.language});
  @override
  State<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends State<BackupPage> {
  late final GoogleSignIn google = GoogleSignIn(
    scopes: [drive.DriveApi.driveAppdataScope, drive.DriveApi.driveFileScope],
    serverClientId: const String.fromEnvironment('GOOGLE_SERVER_CLIENT_ID').isEmpty
        ? null
        : const String.fromEnvironment('GOOGLE_SERVER_CLIENT_ID'),
  );
  GoogleSignInAccount? account;
  String? status;
  StreamSubscription<GoogleSignInAccount?>? authSubscription;

  String label(String key) => T.s(widget.language, key);

  @override
  void initState() {
    super.initState();
    authSubscription = google.onCurrentUserChanged.listen((user) {
      if (mounted) setState(() => account = user);
    });
    google.signInSilently().then((user) {
      if (!mounted || user == null) return;
      setState(() => account = user);
      if (AppStore.instance.prefs.getBool('autoBackup') == true) driveBackup();
    }).catchError((Object error) {
      if (mounted) setState(() => status = '$error');
    });
  }

  @override
  void dispose() {
    authSubscription?.cancel();
    super.dispose();
  }

  Future<bool> confirmRestore() async => await showDialog<bool>(
    context: context,
    builder: (_) => AlertDialog(
      content: Text(label('chooseRestore')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: Text(label('cancel'))),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(label('yes'))),
      ],
    ),
  ) ?? false;

  Future<void> connect() async {
    try {
      final user = await google.signIn();
      if (mounted) setState(() => account = user);
    } catch (error) {
      if (mounted) setState(() => status = '$error');
    }
  }

  Future<drive.DriveApi> driveApi() async {
    final user = account ?? await google.signIn();
    if (user == null) throw Exception('Google sign-in cancelled');
    final headers = await user.authHeaders;
    return drive.DriveApi(_GoogleAuthClient(headers));
  }

  Future<void> driveBackup() async {
    try {
      final api = await driveApi();
      final bytes = utf8.encode(jsonEncode(await AppStore.instance.exportAll()));
      final media = drive.Media(Stream<List<int>>.value(bytes), bytes.length, contentType: 'application/json');
      final file = drive.File()
        ..name = 'QUPTAN_PRO_BACKUP.json'
        ..mimeType = 'application/json'
        ..parents = ['appDataFolder'];
      final existing = await api.files.list(
        spaces: 'appDataFolder',
        q: "name='QUPTAN_PRO_BACKUP.json' and trashed=false",
        $fields: 'files(id)',
        pageSize: 5,
      );
      final result = existing.files != null && existing.files!.isNotEmpty
          ? await api.files.update(file, existing.files!.first.id!, uploadMedia: media)
          : await api.files.create(file, uploadMedia: media);
      if (mounted) setState(() => status = 'Drive: ${result.id}');
    } catch (error) {
      if (mounted) setState(() => status = 'Google Drive error: $error');
    }
  }

  Future<void> driveRestore() async {
    try {
      if (!await confirmRestore() || !mounted) return;
      final api = await driveApi();
      final found = await api.files.list(
        spaces: 'appDataFolder',
        q: "name='QUPTAN_PRO_BACKUP.json' and trashed=false",
        $fields: 'files(id,name,modifiedTime)',
        orderBy: 'modifiedTime desc',
        pageSize: 5,
      );
      if (found.files == null || found.files!.isEmpty) throw Exception('No backup found');
      final media = await api.files.get(found.files!.first.id!, downloadOptions: drive.DownloadOptions.fullMedia) as drive.Media;
      final chunks = <int>[];
      await for (final chunk in media.stream) {
        chunks.addAll(chunk);
      }
      await AppStore.instance.importAll(jsonDecode(utf8.decode(chunks)) as Map<String, dynamic>);
      if (mounted) setState(() => status = label('success'));
    } catch (error) {
      if (mounted) setState(() => status = 'Google Drive error: $error');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(label('backup'))),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Text(label('driveBackup'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
      const SizedBox(height: 10),
      Text(account?.email ?? label('notConnected')),
      SwitchListTile(
        title: Text(label('autoBackup')),
        value: AppStore.instance.prefs.getBool('autoBackup') ?? false,
        onChanged: (value) async {
          await AppStore.instance.prefs.setBool('autoBackup', value);
          if (mounted) setState(() {});
        },
      ),
      OutlinedButton.icon(onPressed: connect, icon: const Icon(Icons.account_circle), label: Text(label('connectGoogle'))),
      FilledButton.icon(onPressed: account == null ? null : driveBackup, icon: const Icon(Icons.cloud_upload), label: Text(label('backupNow'))),
      OutlinedButton.icon(onPressed: account == null ? null : driveRestore, icon: const Icon(Icons.cloud_download), label: Text(label('restoreDrive'))),
      if (status != null) Padding(padding: const EdgeInsets.only(top: 16), child: Text(status!, style: const TextStyle(color: gold))),
    ]),
  );
}

class _GoogleAuthClient extends http.BaseClient {
  final Map<String, String> headers;
  final http.Client client = http.Client();
  _GoogleAuthClient(this.headers);

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) {
    request.headers.addAll(headers);
    return client.send(request);
  }

  @override
  void close() => client.close();
}
