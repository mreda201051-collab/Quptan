import 'package:flutter/material.dart';
import 'data/app_database.dart';
import 'data/repository.dart';
import 'ui/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final repository = AppRepository(AppDatabase.instance);
  await AppDatabase.instance.database;
  runApp(QuptanApp(repository: repository));
}

class QuptanApp extends StatelessWidget {
  const QuptanApp({super.key, required this.repository});
  final AppRepository repository;
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'QUPTAN WE EGYPT PRO', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, brightness: Brightness.dark, scaffoldBackgroundColor: const Color(0xFF090B16),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8055D8), brightness: Brightness.dark, surface: const Color(0xFF15182A)),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF101326), foregroundColor: Color(0xFFFFD779), centerTitle: true),
      cardTheme: CardThemeData(color: const Color(0xFF171B30), elevation: 1, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
      fontFamily: null),
    locale: const Locale('ar'), supportedLocales: const [Locale('ar'), Locale('en')],
    home: Directionality(textDirection: TextDirection.rtl, child: HomeScreen(repository: repository)),
  );
}
