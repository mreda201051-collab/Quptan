import 'package:flutter_test/flutter_test.dart';
import 'package:quptan_we_egypt_pro/domain/financials.dart';

void main() {
  test('payment history is summed without exceeding zero debt', () {
    const sale = SaleSnapshot(price: 970, cost: 835, gb: 100, payments: [280, 200]);
    expect(sale.paid, 480);
    expect(sale.remaining, 490);
    expect(sale.profit, 135);
  });
  test('dashboard totals match the source accounting definitions', () {
    final totals = calculateTotals(sales: const [SaleSnapshot(price: 970, cost: 835, gb: 100, payments: [280])], mainLineCosts: 8500, otherExpenses: 100, stockGb: 1020);
    expect(totals.netSalesProfit, 135);
    expect(totals.cashBalance, -8320);
    expect(totals.leftGb, 920);
  });
  test('remaining balance never becomes negative after overpayment', () {
    const sale = SaleSnapshot(price: 100, cost: 40, gb: 5, payments: [80, 50]);
    expect(sale.paid, 130);
    expect(sale.remaining, 0);
    expect(sale.profit, 60);
  });
}
