import 'package:flutter_test/flutter_test.dart';
import 'package:quptan_we_egypt_pro/main.dart';

void main() {
  test('Arabic and English core labels are present', () {
    expect(T.s('ar', 'home'), 'الرئيسية');
    expect(T.s('en', 'home'), 'Home');
    expect(T.s('en', 'backup'), 'Backup & restore');
  });
}
