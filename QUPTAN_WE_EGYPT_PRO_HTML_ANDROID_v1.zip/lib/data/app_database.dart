import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;
  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    final root = await getDatabasesPath();
    return openDatabase(p.join(root, 'quptan_we_egypt.db'), version: 1, onConfigure: (db) async {
      await db.execute('PRAGMA foreign_keys = ON');
    }, onCreate: (db, version) async {
      await db.execute('''CREATE TABLE packages(id INTEGER PRIMARY KEY, name TEXT NOT NULL, gb REAL NOT NULL, minutes INTEGER NOT NULL, cost REAL NOT NULL, price REAL NOT NULL, active INTEGER NOT NULL DEFAULT 1)''');
      await db.execute('''CREATE TABLE main_lines(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, start_date TEXT, renew_date TEXT, total_gb REAL NOT NULL DEFAULT 0, total_minutes INTEGER NOT NULL DEFAULT 0, cost REAL NOT NULL DEFAULT 0, notes TEXT)''');
      await db.execute('''CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT NOT NULL, phone TEXT NOT NULL, package_id INTEGER, line_id INTEGER, gb REAL NOT NULL DEFAULT 0, minutes INTEGER NOT NULL DEFAULT 0, sale_date TEXT NOT NULL, activation_date TEXT NOT NULL, expiry_date TEXT, cost REAL NOT NULL DEFAULT 0, original_price REAL NOT NULL DEFAULT 0, discount REAL NOT NULL DEFAULT 0, price REAL NOT NULL DEFAULT 0, payment_method TEXT, notes TEXT, FOREIGN KEY(package_id) REFERENCES packages(id), FOREIGN KEY(line_id) REFERENCES main_lines(id))''');
      await db.execute('''CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, amount REAL NOT NULL CHECK(amount > 0), payment_date TEXT NOT NULL, method TEXT NOT NULL, notes TEXT, FOREIGN KEY(sale_id) REFERENCES sales(id) ON DELETE CASCADE)''');
      await db.execute('''CREATE TABLE bookings(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT NOT NULL, phone TEXT NOT NULL, package_id INTEGER, line_id INTEGER, gb REAL NOT NULL DEFAULT 0, minutes INTEGER NOT NULL DEFAULT 0, booking_date TEXT NOT NULL, activation_date TEXT, expiry_date TEXT, cost REAL NOT NULL DEFAULT 0, original_price REAL NOT NULL DEFAULT 0, discount REAL NOT NULL DEFAULT 0, price REAL NOT NULL DEFAULT 0, payment_method TEXT, notes TEXT, FOREIGN KEY(package_id) REFERENCES packages(id), FOREIGN KEY(line_id) REFERENCES main_lines(id))''');
      await db.execute('''CREATE TABLE booking_payments(id INTEGER PRIMARY KEY AUTOINCREMENT, booking_id INTEGER NOT NULL, amount REAL NOT NULL CHECK(amount > 0), payment_date TEXT NOT NULL, method TEXT NOT NULL, FOREIGN KEY(booking_id) REFERENCES bookings(id) ON DELETE CASCADE)''');
      await db.execute('''CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT, expense_date TEXT NOT NULL, description TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 1, gb REAL NOT NULL DEFAULT 0, amount REAL NOT NULL DEFAULT 0, notes TEXT)''');
      await db.execute('''CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)''');
      await db.execute('CREATE INDEX idx_sales_activation ON sales(activation_date)');
      await db.execute('CREATE INDEX idx_sales_phone ON sales(phone)');
      await db.execute('CREATE INDEX idx_payments_date ON payments(payment_date)');
      await db.execute('CREATE INDEX idx_bookings_activation ON bookings(activation_date)');
      await _seedPackages(db);
      await db.insert('settings', {'key':'schema_source','value':'QUPTAN WE EGYPT PRO / migrated from original HTML specification'});
    });
  }

  Future<void> _seedPackages(DatabaseExecutor db) async {
    const rows = [
      [1,'5 جيجا + 500 دقيقة',5,500,45,120],[2,'10 جيجا + 500 دقيقة',10,500,85,180],
      [3,'15 جيجا + 1000 دقيقة',15,1000,125,235],[4,'20 جيجا + 1500 دقيقة',20,1500,170,280],
      [5,'30 جيجا + 1500 دقيقة',30,1500,250,365],[6,'40 جيجا + 1500 دقيقة',40,1500,335,450],
      [7,'50 جيجا + 1500 دقيقة',50,1500,420,530],[8,'60 جيجا + 1500 دقيقة',60,1500,500,590],
      [9,'70 جيجا + 2000 دقيقة',70,2000,585,680],[10,'80 جيجا + 2000 دقيقة',80,2000,670,780],
      [11,'100 جيجا + 2000 دقيقة',100,2000,835,970],[12,'إضافة 5 جيجا',5,0,42,80],
    ];
    for (final r in rows) {
      await db.insert('packages', {'id':r[0],'name':r[1],'gb':r[2],'minutes':r[3],'cost':r[4],'price':r[5]}, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
  }
}
