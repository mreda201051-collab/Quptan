import 'package:sqflite/sqflite.dart';
import 'dart:convert';
import 'app_database.dart';
import '../domain/report_period.dart';

class AppRepository {
  AppRepository(this._database);
  final AppDatabase _database;
  Future<List<Map<String,Object?>>> packages() async => (await _database.database).query('packages', where:'active=1', orderBy:'gb ASC');
  Future<List<Map<String,Object?>>> sales() async => (await _database.database).rawQuery('''SELECT s.*, COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.sale_id=s.id),0) paid, MAX(0,s.price-COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.sale_id=s.id),0)) remaining FROM sales s ORDER BY s.id DESC''');
  Future<List<Map<String,Object?>>> bookings() async => (await _database.database).rawQuery('''SELECT b.*, COALESCE((SELECT SUM(p.amount) FROM booking_payments p WHERE p.booking_id=b.id),0) paid, MAX(0,b.price-COALESCE((SELECT SUM(p.amount) FROM booking_payments p WHERE p.booking_id=b.id),0)) remaining FROM bookings b ORDER BY b.gb DESC, b.id ASC''');
  Future<List<Map<String,Object?>>> customers() async => (await _database.database).rawQuery('''SELECT MAX(customer_name) customer_name, MAX(phone) phone, COUNT(*) sales_count,
    COALESCE(SUM(price),0) total, COALESCE(SUM(discount),0) discounts,
    COALESCE(SUM((SELECT COALESCE(SUM(p.amount),0) FROM payments p WHERE p.sale_id=s.id)),0) paid,
    COALESCE(SUM(MAX(0,price-COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.sale_id=s.id),0))),0) debt
    FROM sales s
    GROUP BY CASE WHEN TRIM(COALESCE(phone,''))<>'' THEN phone ELSE customer_name END
    ORDER BY MAX(customer_name) COLLATE NOCASE''');
  Future<int> createBooking(Map<String,Object?> booking, {double initialPayment=0, String paymentDate='', String method='إنستاباي'}) async {
    final db=await _database.database;
    return db.transaction((txn) async {
      final price=(booking['price'] as num?)?.toDouble()??0;
      if(price<=0||initialPayment<0||initialPayment>price)throw ArgumentError('راجع سعر الحجز ومقدم الحجز');
      final id=await txn.insert('bookings',booking);
      if(initialPayment>0)await txn.insert('booking_payments',{'booking_id':id,'amount':initialPayment,'payment_date':paymentDate,'method':method});
      return id;
    });
  }

  Future<int> updateSale(int id, Map<String,Object?> sale) async {
    final db = await _database.database;
    return db.transaction((txn) async {
      final existing = await txn.query('sales', where:'id=?', whereArgs:[id], limit:1);
      if (existing.isEmpty) throw StateError('عملية البيع غير موجودة');
      final paidRows = await txn.rawQuery('SELECT COALESCE(SUM(amount),0) paid FROM payments WHERE sale_id=?', [id]);
      final paid = (paidRows.first['paid'] as num).toDouble();
      final newPrice = (sale['price'] as num?)?.toDouble() ?? 0;
      for(final key in ['price','cost','original_price','discount','gb','minutes']){final value=sale[key];if(value is num && value<0)throw ArgumentError('لا يمكن إدخال قيمة سالبة في $key');}
      if (newPrice < paid) throw ArgumentError('لا يمكن جعل السعر أقل من إجمالي المبالغ المحصلة');
      await txn.update('sales', sale, where:'id=?', whereArgs:[id]);
      return id;
    });
  }

  Future<int> updateBooking(int id, Map<String,Object?> booking) async {
    final db = await _database.database;
    return db.transaction((txn) async {
      final existing = await txn.query('bookings', where:'id=?', whereArgs:[id], limit:1);
      if (existing.isEmpty) throw StateError('الحجز غير موجود');
      final paidRows = await txn.rawQuery('SELECT COALESCE(SUM(amount),0) paid FROM booking_payments WHERE booking_id=?', [id]);
      final paid = (paidRows.first['paid'] as num).toDouble();
      final newPrice = (booking['price'] as num?)?.toDouble() ?? 0;
      for(final key in ['price','cost','original_price','discount','gb','minutes']){final value=booking[key];if(value is num && value<0)throw ArgumentError('لا يمكن إدخال قيمة سالبة في $key');}
      if (newPrice < paid) throw ArgumentError('لا يمكن جعل سعر الحجز أقل من إجمالي المبالغ المحصلة');
      return txn.update('bookings', booking, where:'id=?', whereArgs:[id]);
    });
  }

  Future<List<Map<String,Object?>>> bookingPayments(int bookingId) async =>
      (await _database.database).query('booking_payments', where:'booking_id=?', whereArgs:[bookingId], orderBy:'payment_date, id');

  Future<List<Map<String,Object?>>> paymentHistory() async =>
      (await _database.database).rawQuery('''SELECT p.*, s.customer_name, s.phone, s.package_id, 'sale' AS record_type FROM payments p JOIN sales s ON s.id=p.sale_id ORDER BY p.payment_date DESC, p.id DESC''');

  Future<int> deletePayment(int paymentId) async =>
      (await _database.database).delete('payments', where:'id=?', whereArgs:[paymentId]);

  Future<List<Map<String,Object?>>> bookingPaymentHistory() async =>
      (await _database.database).rawQuery('''SELECT p.*, b.customer_name, b.phone, b.package_id, 'booking' AS record_type FROM booking_payments p JOIN bookings b ON b.id=p.booking_id ORDER BY p.payment_date DESC, p.id DESC''');

  Future<int> addBookingPayment({required int bookingId, required double amount, required String date, required String method}) async {
    final db = await _database.database;
    return db.transaction((txn) async {
      final rows = await txn.rawQuery('''SELECT b.price-COALESCE((SELECT SUM(p.amount) FROM booking_payments p WHERE p.booking_id=b.id),0) due FROM bookings b WHERE b.id=?''', [bookingId]);
      if (rows.isEmpty) throw StateError('الحجز غير موجود');
      final due = (rows.first['due'] as num).toDouble();
      if (amount <= 0 || amount > due) throw ArgumentError('قيمة التحصيل يجب أن تكون أكبر من صفر ولا تتجاوز المتبقي');
      return txn.insert('booking_payments', {'booking_id':bookingId,'amount':amount,'payment_date':date,'method':method});
    });
  }

  Future<int> deleteBookingPayment(int paymentId) async =>
      (await _database.database).delete('booking_payments', where:'id=?', whereArgs:[paymentId]);

  Future<int> promoteDueBookings({required String today}) async {
    final db = await _database.database;
    return db.transaction((txn) async {
      final due = await txn.query('bookings', where:"activation_date IS NOT NULL AND TRIM(activation_date)<>'' AND activation_date<=?", whereArgs:[today], orderBy:'activation_date, id');
      var moved = 0;
      for (final booking in due) {
        final b = Map<String,Object?>.from(booking)..remove('id');
        b['sale_date'] = b.remove('booking_date');
        b['activation_date'] ??= today;
        final saleId = await txn.insert('sales', b);
        final payments = await txn.query('booking_payments', where:'booking_id=?', whereArgs:[booking['id']]);
        for (final payment in payments) {
          await txn.insert('payments', {'sale_id':saleId,'amount':payment['amount'],'payment_date':payment['payment_date'],'method':payment['method'],'notes':'مرحل من دفعة حجز'});
        }
        await txn.delete('bookings', where:'id=?', whereArgs:[booking['id']]);
        moved++;
      }
      return moved;
    });
  }
  Future<int> deleteSale(int id) async => (await _database.database).delete('sales', where:'id=?', whereArgs:[id]);
  Future<int> deleteBooking(int id) async => (await _database.database).delete('bookings', where:'id=?', whereArgs:[id]);
  Future<int> addPayment({required int saleId, required double amount, required String date, required String method}) async {
    final db = await _database.database;
    return db.transaction((txn) async {
      final rows = await txn.rawQuery('SELECT price-COALESCE((SELECT SUM(amount) FROM payments WHERE sale_id=?),0) AS due FROM sales WHERE id=?', [saleId,saleId]);
      if (rows.isEmpty) throw StateError('البيع غير موجود');
      final due = (rows.first['due'] as num).toDouble();
      if (amount <= 0 || amount > due) throw ArgumentError('قيمة التحصيل يجب أن تكون أكبر من صفر ولا تتجاوز المتبقي');
      return txn.insert('payments', {'sale_id':saleId,'amount':amount,'payment_date':date,'method':method});
    });
  }
  Future<int> createSale(Map<String,Object?> sale, {double initialPayment=0, String paymentDate='', String method='إنستاباي'}) async {
    final db = await _database.database;
    return db.transaction((txn) async {
      final price=(sale['price'] as num?)?.toDouble()??0;
      if(price<=0||initialPayment<0||initialPayment>price)throw ArgumentError('راجع سعر البيع والمبلغ المدفوع');
      final id = await txn.insert('sales', sale);
      if (initialPayment > 0) await txn.insert('payments', {'sale_id':id,'amount':initialPayment,'payment_date':paymentDate,'method':method});
      return id;
    });
  }
  /// Promotion is atomic: the booking and its payment history move together.
  Future<int> promoteBooking(int bookingId) async {
    final db = await _database.database;
    return db.transaction((txn) async {
      final found = await txn.query('bookings', where:'id=?', whereArgs:[bookingId], limit:1);
      if (found.isEmpty) throw StateError('الحجز غير موجود');
      final b = Map<String,Object?>.from(found.first)..remove('id');
      b['sale_date'] = b.remove('booking_date');
      b['activation_date'] ??= b['sale_date'];
      final saleId = await txn.insert('sales', b);
      final payments = await txn.query('booking_payments', where:'booking_id=?', whereArgs:[bookingId]);
      for (final payment in payments) {
        await txn.insert('payments', {'sale_id':saleId,'amount':payment['amount'],'payment_date':payment['payment_date'],'method':payment['method']});
      }
      await txn.delete('bookings', where:'id=?', whereArgs:[bookingId]);
      return saleId;
    });
  }
  Future<Map<String,double>> dashboardTotals() async {
    final db = await _database.database;
    final rows = await db.rawQuery('''SELECT COALESCE(SUM(price),0) sales, COALESCE(SUM(cost),0) cost, COALESCE(SUM(gb),0) sold_gb, COALESCE(SUM((SELECT SUM(amount) FROM payments p WHERE p.sale_id=s.id)),0) collected, COALESCE(SUM(MAX(0,price-COALESCE((SELECT SUM(amount) FROM payments p WHERE p.sale_id=s.id),0))),0) debt FROM sales s''');
    final r=rows.first;
    final lines=await db.rawQuery('SELECT COALESCE(SUM(cost),0) v, COALESCE(SUM(total_gb),0) g FROM main_lines');
    final exp=await db.rawQuery('SELECT COALESCE(SUM(amount),0) v, COALESCE(SUM(gb),0) g FROM expenses');
    final line=lines.first, expense=exp.first;
    final stock=(line['g'] as num).toDouble()>0?(line['g'] as num).toDouble():(expense['g'] as num).toDouble();
    return {'sales':(r['sales'] as num).toDouble(),'cost':(r['cost'] as num).toDouble(),'collected':(r['collected'] as num).toDouble(),'debt':(r['debt'] as num).toDouble(),'soldGb':(r['sold_gb'] as num).toDouble(),'expenses':(line['v'] as num).toDouble()+(expense['v'] as num).toDouble(),'stockGb':stock};
  }
  Future<List<Map<String,Object?>>> mainLines() async {
    final db = await _database.database;
    return db.rawQuery("""SELECT l.*,
      COALESCE((SELECT SUM(s.gb) FROM sales s WHERE s.line_id=l.id),0) used_gb,
      COALESCE((SELECT SUM(s.minutes) FROM sales s WHERE s.line_id=l.id),0) used_minutes
      FROM main_lines l ORDER BY l.id""");
  }

  Future<int> saveMainLine(Map<String,Object?> line, {int? id}) async {
    final db = await _database.database;
    if (id == null) return db.insert('main_lines', line);
    return db.update('main_lines', line, where:'id=?', whereArgs:[id]);
  }

  Future<int> deleteMainLine(int id) async {
    final db = await _database.database;
    final used = await db.query('sales', columns:['id'], where:'line_id=?', whereArgs:[id], limit:1);
    final booked = await db.query('bookings', columns:['id'], where:'line_id=?', whereArgs:[id], limit:1);
    if (used.isNotEmpty || booked.isNotEmpty) throw StateError('لا يمكن حذف الخط لأنه مرتبط بمبيعات أو حجوزات. عدّل بياناته بدلاً من ذلك.');
    return db.delete('main_lines', where:'id=?', whereArgs:[id]);
  }

  Future<List<Map<String,Object?>>> expenses() async =>
      (await _database.database).query('expenses', orderBy:'expense_date DESC, id DESC');

  Future<int> saveExpense(Map<String,Object?> expense, {int? id}) async {
    final db = await _database.database;
    if (id == null) return db.insert('expenses', expense);
    return db.update('expenses', expense, where:'id=?', whereArgs:[id]);
  }

  Future<int> deleteExpense(int id) async =>
      (await _database.database).delete('expenses', where:'id=?', whereArgs:[id]);

  Future<int> savePackage(Map<String,Object?> package, {int? id}) async {
    final db = await _database.database;
    if (id == null) return db.insert('packages', package);
    return db.update('packages', package, where:'id=?', whereArgs:[id]);
  }

  Future<int> archivePackage(int id) async {
    final db = await _database.database;
    return db.update('packages', {'active':0}, where:'id=?', whereArgs:[id]);
  }

  Future<Map<String,Object?>> report({String? from, String? to}) async {
    final db = await _database.database;
    final clauses = <String>[];
    final args = <Object?>[];
    if (from != null && from.isNotEmpty) { clauses.add('activation_date >= ?'); args.add(from); }
    if (to != null && to.isNotEmpty) { clauses.add('activation_date <= ?'); args.add(to); }
    final where = clauses.isEmpty ? '' : 'WHERE ${clauses.join(' AND ')}';
    final salesRows = await db.rawQuery("""SELECT s.*,
      COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.sale_id=s.id),0) paid,
      MAX(0,s.price-COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.sale_id=s.id),0)) remaining
      FROM sales s $where ORDER BY activation_date DESC""", args);
    final summary = await db.rawQuery("""SELECT COALESCE(SUM(price),0) sold,
      COALESCE(SUM(discount),0) discounts, COALESCE(SUM(cost),0) sales_cost,
      COALESCE(SUM(gb),0) sold_gb,
      COALESCE(SUM(MAX(0,price-COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.sale_id=s.id),0))),0) debt
      FROM sales s $where""", args);
    // The source report counts collections by payment date, not by sale date.
    final payClauses = <String>[]; final payArgs = <Object?>[];
    if (from != null && from.isNotEmpty) { payClauses.add('payment_date >= ?'); payArgs.add(from); }
    if (to != null && to.isNotEmpty) { payClauses.add('payment_date <= ?'); payArgs.add(to); }
    final payWhere = payClauses.isEmpty ? '' : 'WHERE ${payClauses.join(' AND ')}';
    final collectedRows = await db.rawQuery('SELECT COALESCE(SUM(amount),0) collected FROM payments $payWhere', payArgs);
    final spentClauses = <String>[]; final spentArgs = <Object?>[];
    if (from != null && from.isNotEmpty) { spentClauses.add('expense_date >= ?'); spentArgs.add(from); }
    if (to != null && to.isNotEmpty) { spentClauses.add('expense_date <= ?'); spentArgs.add(to); }
    final spentWhere = spentClauses.isEmpty ? '' : 'WHERE ${spentClauses.join(' AND ')}';
    final extraRows = await db.rawQuery('SELECT COALESCE(SUM(amount),0) total FROM expenses $spentWhere', spentArgs);
    final lineClauses = <String>[]; final lineArgs = <Object?>[];
    if (from != null && from.isNotEmpty) { lineClauses.add('start_date >= ?'); lineArgs.add(from); }
    if (to != null && to.isNotEmpty) { lineClauses.add('start_date <= ?'); lineArgs.add(to); }
    final lineWhere = lineClauses.isEmpty ? '' : 'WHERE ${lineClauses.join(' AND ')}';
    final lineRows = await db.rawQuery('SELECT COALESCE(SUM(cost),0) total FROM main_lines $lineWhere', lineArgs);
    final s = summary.first;
    final salesProfit = (s['sold'] as num).toDouble() - (s['sales_cost'] as num).toDouble();
    final spent = (extraRows.first['total'] as num).toDouble() + (lineRows.first['total'] as num).toDouble();
    final allDebt = await db.rawQuery("""SELECT COALESCE(SUM(MAX(0,price-COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.sale_id=s.id),0))),0) debt FROM sales s""");
    return {
      'salesRows': salesRows, 'sold': (s['sold'] as num).toDouble(),
      'discounts': (s['discounts'] as num).toDouble(), 'salesCost': (s['sales_cost'] as num).toDouble(),
      'salesProfit': salesProfit, 'collected': (collectedRows.first['collected'] as num).toDouble(),
      'debt': (s['debt'] as num).toDouble(), 'allDebt': (allDebt.first['debt'] as num).toDouble(),
      'spent': spent, 'lineSpent': (lineRows.first['total'] as num).toDouble(),
      'extraSpent': (extraRows.first['total'] as num).toDouble(),
      'netAfterSpent': salesProfit - spent, 'soldGb': (s['sold_gb'] as num).toDouble(),
    };
  }

  Future<Map<String,Object?>> cycleReport({required int year, required int month}) {
    final period = ReportPeriod.cycle16(year:year, month:month);
    return report(from:period.start, to:period.end);
  }

  Future<String> exportBackupJson() async {
    final db = await _database.database;
    final data = <String,Object?>{'format':'quptan-we-backup','version':1,'createdAt':DateTime.now().toIso8601String()};
    for (final table in ['packages','main_lines','sales','payments','bookings','booking_payments','expenses','settings']) {
      data[table] = await db.query(table);
    }
    return const JsonEncoder.withIndent('  ').convert(data);
  }

  Future<void> restoreBackupJson(String source) async {
    final decoded = jsonDecode(source);
    if (decoded is! Map<String,dynamic> || decoded['format'] != 'quptan-we-backup' || decoded['version'] != 1) {
      throw const FormatException('ملف النسخة الاحتياطية غير معروف أو غير مدعوم');
    }
    const tables = ['packages','main_lines','sales','payments','bookings','booking_payments','expenses','settings'];
    for (final table in tables) {
      if (decoded[table] is! List) throw FormatException('بيانات جدول $table غير موجودة');
      for (final row in decoded[table] as List) {
        if (row is! Map) throw FormatException('سجل غير صالح داخل $table');
      }
    }
    final db = await _database.database;
    await db.transaction((txn) async {
      for (final table in ['payments','booking_payments','sales','bookings','main_lines','packages','expenses','settings']) {
        await txn.delete(table);
      }
      for (final table in tables) {
        for (final raw in decoded[table] as List) {
          await txn.insert(table, Map<String,Object?>.from(raw as Map));
        }
      }
    });
  }

  Future<int> renewSale(int saleId, {required String today}) async {
    final db = await _database.database;
    return db.transaction((txn) async {
      final rows = await txn.query('sales', where:'id=?', whereArgs:[saleId], limit:1);
      if (rows.isEmpty) throw StateError('الاشتراك الأصلي غير موجود');
      final old = Map<String,Object?>.from(rows.first)..remove('id');
      final start = DateTime.parse(today);
      final expiry = start.add(const Duration(days:30));
      old['sale_date'] = today;
      old['activation_date'] = today;
      old['expiry_date'] = expiry.toIso8601String().substring(0,10);
      old['payment_method'] = old['payment_method'] ?? 'إنستاباي';
      return txn.insert('sales', old);
    });
  }

  Future<int> distributeBookingsSmart() async {
    final db = await _database.database;
    return db.transaction((txn) async {
      final lines = await txn.query('main_lines', orderBy:'id ASC');
      final bookings = await txn.query('bookings', orderBy:'gb DESC, id ASC');
      if (bookings.isEmpty || lines.isEmpty) return 0;
      final normal = lines.where((l) => !'${l['name']}'.contains('01514166575')).toList();
      final priority = lines.where((l) => '${l['name']}'.contains('01514166575')).toList();
      final ordered = [...normal, ...priority];
      final states = ordered.map((line) => <String,Object?>{
        'line':line, 'last': identical(line, ordered.last) || '${line['name']}'.contains('01514166575'),
        'used':0.0, 'assigned':<Map<String,Object?>>[],
      }).toList();
      final normalStates = states.where((s) => s['last'] != true).toList();
      final leftovers = <Map<String,Object?>>[];
      for (final booking in bookings) {
        final gb = (booking['gb'] as num).toDouble();
        final candidates = normalStates.where((s) => (s['assigned'] as List).length < 6).toList();
        final fits = candidates.where((s) {
          final cap=((s['line'] as Map)['total_gb'] as num).toDouble();
          return cap > 0 && cap - (s['used'] as double) >= gb;
        }).toList()..sort((a,b) {
          final la=a['line'] as Map, lb=b['line'] as Map;
          final ca=(la['total_gb'] as num).toDouble()-(a['used'] as double)-gb;
          final cb=(lb['total_gb'] as num).toDouble()-(b['used'] as double)-gb;
          return ca.compareTo(cb);
        });
        if (fits.isNotEmpty) {
          final chosen=fits.first; (chosen['assigned'] as List).add(booking); chosen['used']=(chosen['used'] as double)+gb;
        } else {
          final open=candidates.where((s)=>(((s['line'] as Map)['total_gb'] as num).toDouble())<=0).toList();
          if(open.isNotEmpty){final chosen=open.first;(chosen['assigned'] as List).add(booking);chosen['used']=(chosen['used'] as double)+gb;} else {leftovers.add(booking);}
        }
      }
      for(final state in normalStates){
        while((state['assigned'] as List).length<6 && leftovers.isNotEmpty){
          final cap=((state['line'] as Map)['total_gb'] as num).toDouble();
          final idx=leftovers.indexWhere((b)=>cap<=0 || cap-(state['used'] as double)>=(b['gb'] as num).toDouble());
          if(idx<0)break;
          final booking=leftovers.removeAt(idx);(state['assigned'] as List).add(booking);state['used']=(state['used'] as double)+(booking['gb'] as num).toDouble();
        }
      }
      final last=states.isEmpty?null:states.last;
      if(last!=null){for(final b in leftovers){(last['assigned'] as List).add(b);last['used']=(last['used'] as double)+(b['gb'] as num).toDouble();}leftovers.clear();}
      var changed=0;
      for(final state in states){final lineId=(state['line'] as Map)['id'] as int;for(final booking in state['assigned'] as List<Map<String,Object?>>){changed+=await txn.update('bookings',{'line_id':lineId},where:'id=?',whereArgs:[booking['id']]);}}
      return changed;
    });
  }

}
