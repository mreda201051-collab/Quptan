import 'package:flutter/material.dart';
import 'dart:io';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/rendering.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart' as pdf;
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:excel/excel.dart';
import 'package:url_launcher/url_launcher.dart';
import '../data/repository.dart';
import '../domain/report_period.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.repository});
  final AppRepository repository;
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;
  late Future<Map<String, double>> _totals;
  late String _reportMonth;
  int _paymentView = 0;
  int _renewalFilter = 0;
  String _salesSearch = '';
  String _bookingsSearch = '';
  String _customersSearch = '';
  static const _titles = ['الرئيسية', 'المبيعات', 'الحجوزات', 'العملاء', 'المدفوعات', 'المصروفات', 'الخطوط الأم', 'الباقات', 'التقارير', 'الإعدادات', 'التجديدات'];
  static const _icons = [Icons.dashboard, Icons.point_of_sale, Icons.bookmark, Icons.people, Icons.payments, Icons.money_off, Icons.sim_card, Icons.inventory, Icons.assessment, Icons.settings, Icons.autorenew];

  @override
  void initState() { super.initState(); _totals = widget.repository.dashboardTotals(); _reportMonth = defaultCycleReferenceMonth(DateTime.now()); _processDueBookings(); }

  Future<void> _processDueBookings() async {
    try {
      final moved = await widget.repository.promoteDueBookings(today: _today());
      if (moved > 0 && mounted) {
        _refresh();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم ترحيل $moved حجز مستحق تلقائيًا إلى المبيعات')));
      }
    } catch (_) { /* Keep app opening even if an automatic promotion needs attention. */ }
  }
  void _refresh() { setState(() { _totals = widget.repository.dashboardTotals(); }); }
  void _go(int value) { setState(() => _index = value); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('QUPTAN WE EGYPT PRO', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: .3)), actions: [if (_index == 2) IconButton(onPressed: _distributeBookings, icon: const Icon(Icons.account_tree), tooltip: 'التوزيع الذكي للحجوزات'), IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh), tooltip: 'تحديث')]),
      drawer: Drawer(child: SafeArea(child: ListView(padding: EdgeInsets.zero, children: [
        const Padding(padding: EdgeInsets.all(22), child: Text('القبطان جروب', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFFFFD779)))),
        for (var i = 0; i < _titles.length; i++) ListTile(selected: i == _index, leading: Icon(_icons[i]), title: Text(_titles[i]), onTap: () { _go(i); Navigator.pop(context); }),
      ]))),
      body: _body(),
      floatingActionButton: [1,2,5,6,7].contains(_index) ? FloatingActionButton.extended(onPressed: () { if (_index == 1) _addSale(); else if (_index == 2) _addBooking(); else if (_index == 5) _editExpense(); else if (_index == 6) _editMainLine(); else _editPackage(); }, icon: const Icon(Icons.add), label: Text(_index == 1 ? 'بيع جديد' : _index == 2 ? 'حجز جديد' : _index == 5 ? 'مصروف جديد' : _index == 6 ? 'خط أم جديد' : 'باقة جديدة')) : null,
      bottomNavigationBar: NavigationBar(selectedIndex: _index < 4 ? _index : 4, onDestinationSelected: (v) { if (v == 4) { _showMore(); } else { _go(v); } }, destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'الرئيسية'),
        NavigationDestination(icon: Icon(Icons.point_of_sale), label: 'المبيعات'),
        NavigationDestination(icon: Icon(Icons.bookmark_border), label: 'الحجوزات'),
        NavigationDestination(icon: Icon(Icons.people_outline), label: 'العملاء'),
        NavigationDestination(icon: Icon(Icons.menu), label: 'المزيد'),
      ]),
    );
  }

  void _showMore() {
    showModalBottomSheet<void>(context: context, builder: (ctx) => SafeArea(child: ListView(shrinkWrap: true, children: [
      for (var i = 4; i < _titles.length; i++) ListTile(leading: Icon(_icons[i]), title: Text(_titles[i]), onTap: () { Navigator.pop(ctx); _go(i); }),
    ])));
  }

  Widget _body() {
    switch (_index) {
      case 0: return _dashboard();
      case 1: return _salesPage();
      case 2: return _bookingsPage();
      case 3: return _customersPage();
      case 5: return _expensesPage();
      case 6: return _mainLinesPage();
      case 7: return _packagesPage();
      case 8: return _reportsPage();
      case 9: return _settingsPage();
      case 10: return _renewalsPage();
      default: return _paymentsPage();
    }
  }

  Widget _dashboard() => FutureBuilder<Map<String, double>>(future: _totals, builder: (context, s) {
    if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
    if (s.hasError) return Center(child: Text('تعذر تحميل لوحة التحكم: ${s.error}'));
    final t = s.data!;
    final cards = [
      ('إجمالي المبيعات', '${t['sales']!.toStringAsFixed(0)} ج.م', Icons.trending_up),
      ('المحصل فعليًا', '${t['collected']!.toStringAsFixed(0)} ج.م', Icons.payments),
      ('مديونيات العملاء', '${t['debt']!.toStringAsFixed(0)} ج.م', Icons.account_balance_wallet),
      ('ربح المبيعات', '${(t['sales']! - t['cost']!).toStringAsFixed(0)} ج.م', Icons.stacked_line_chart),
      ('المصروفات', '${t['expenses']!.toStringAsFixed(0)} ج.م', Icons.receipt_long),
      ('رصيد الخزينة', '${(t['collected']! - t['expenses']!).toStringAsFixed(0)} ج.م', Icons.account_balance),
      ('الجيجات المباعة', '${t['soldGb']!.toStringAsFixed(1)} GB', Icons.data_usage),
      ('المتبقي بالمخزون', '${(t['stockGb']! - t['soldGb']!).toStringAsFixed(1)} GB', Icons.inventory_2),
    ];
    return RefreshIndicator(onRefresh: () async { _refresh(); await _totals; }, child: ListView(padding: const EdgeInsets.all(14), children: [
      const Text('لوحة التحكم', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: Color(0xFFFFD779))), const SizedBox(height: 14),
      GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: cards.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.45, crossAxisSpacing: 10, mainAxisSpacing: 10), itemBuilder: (context, i) { final c = cards[i]; return Card(child: Padding(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Icon(c.$3, color: const Color(0xFFFFD779)), Text(c.$1, style: const TextStyle(color: Colors.white70)), FittedBox(child: Text(c.$2, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)))]))); }),
      const SizedBox(height: 18), const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('قاعدة البيانات محلية على الجهاز. لا توجد بيانات عملاء أو مبيعات تجريبية.', style: TextStyle(height: 1.6, color: Colors.white70)))),
    ]));
  });

  Widget _salesPage() => FutureBuilder<List<Map<String, Object?>>>(
    future: widget.repository.sales(),
    builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final rows = snap.data!.where((r) => '${r['customer_name']} ${r['phone']} ${r['id']}'.toLowerCase().contains(_salesSearch.toLowerCase())).toList();
      return Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(12, 12, 12, 4), child: TextField(
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'بحث بالاسم أو الهاتف أو رقم العملية', border: OutlineInputBorder()),
          onChanged: (v) => setState(() => _salesSearch = v),
        )),
        Expanded(child: rows.isEmpty
          ? _empty('لا توجد نتائج للمبيعات', 'أضف عملية بيع أو غيّر كلمات البحث')
          : RefreshIndicator(onRefresh: () async => setState(() {}), child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 90), itemCount: rows.length,
              itemBuilder: (context, i) {
                final row = rows[i];
                final paid = (row['paid'] as num).toDouble();
                final due = (row['remaining'] as num).toDouble();
                return Card(child: ListTile(
                  leading: CircleAvatar(backgroundColor: due == 0 ? Colors.green.shade800 : Colors.deepPurple.shade700, child: const Icon(Icons.person)),
                  title: Text('${row['customer_name']}'),
                  subtitle: Text('${row['phone']} • ${row['gb']} جيجا\nالسعر: ${_money(row['price'])} | المدفوع: ${_money(paid)} | المتبقي: ${_money(due)}', style: const TextStyle(height: 1.6)),
                  isThreeLine: true,
                  trailing: PopupMenuButton<String>(
                    onSelected: (v) {
                      if (v == 'pay') _addPayment(row);
                      if (v == 'edit') _editSale(row);
                      if (v == 'waDebt') _sendSaleWhatsApp(row, 'debt');
                      if (v == 'waRenew') _sendSaleWhatsApp(row, 'renew');
                      if (v == 'waActivate') _sendActivationWhatsApp(row);
                      if (v == 'invoice') _showInvoice(row);
                      if (v == 'delete') _confirmDelete('حذف عملية البيع؟', () async { await widget.repository.deleteSale(row['id'] as int); _refresh(); });
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'pay', child: Text('تسجيل تحصيل')),
                      PopupMenuItem(value: 'edit', child: Text('تعديل بيانات البيع')),
                      PopupMenuItem(value: 'waDebt', child: Text('تذكير واتساب بالمديونية')),
                      PopupMenuItem(value: 'waRenew', child: Text('تذكير واتساب بالتجديد')),
                      PopupMenuItem(value: 'waActivate', child: Text('إرسال تأكيد التفعيل واتساب')),
                      PopupMenuItem(value: 'invoice', child: Text('إنشاء فاتورة ومشاركتها')),
                      PopupMenuItem(value: 'delete', child: Text('حذف البيع')),
                    ],
                  ),
                ));
              },
            ))),
      ]);
    },
  );

  Widget _bookingsPage() => FutureBuilder<List<Map<String, Object?>>>(
    future: widget.repository.bookings(),
    builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final rows = snap.data!.where((r) => '${r['customer_name']} ${r['phone']} ${r['id']}'.toLowerCase().contains(_bookingsSearch.toLowerCase())).toList();
      return Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(12, 12, 12, 4), child: TextField(
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'بحث بالاسم أو الهاتف أو رقم الحجز', border: OutlineInputBorder()),
          onChanged: (v) => setState(() => _bookingsSearch = v),
        )),
        Expanded(child: rows.isEmpty
          ? _empty('لا توجد نتائج للحجوزات', 'أضف حجزًا جديدًا أو غيّر كلمات البحث')
          : RefreshIndicator(onRefresh: () async => setState(() {}), child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 90), itemCount: rows.length,
              itemBuilder: (context, i) {
                final row = rows[i];
                final paid = (row['paid'] as num).toDouble();
                final due = (row['remaining'] as num).toDouble();
                return Card(child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.bookmark)),
                  title: Text('${row['customer_name']}'),
                  subtitle: Text('${row['phone']} • ${row['gb']} جيجا\nالتفعيل: ${row['activation_date'] ?? 'غير محدد'} • السعر: ${_money(row['price'])}\nمدفوع: ${_money(paid)} • متبقي: ${_money(due)}', style: const TextStyle(height: 1.6)),
                  isThreeLine: true,
                  trailing: PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'pay') _addBookingPayment(row);
                      if (v == 'edit') _editBooking(row);
                      if (v == 'promote') { await widget.repository.promoteBooking(row['id'] as int); _refresh(); setState(() {}); }
                      if (v == 'delete') _confirmDelete('حذف الحجز؟', () async { await widget.repository.deleteBooking(row['id'] as int); setState(() {}); });
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'pay', child: Text('تسجيل دفعة حجز')),
                      PopupMenuItem(value: 'edit', child: Text('تعديل بيانات الحجز')),
                      PopupMenuItem(value: 'promote', child: Text('ترحيل إلى المبيعات')),
                      PopupMenuItem(value: 'delete', child: Text('حذف الحجز')),
                    ],
                  ),
                ));
              },
            ))),
      ]);
    },
  );

  Widget _customersPage() => FutureBuilder<List<Map<String, Object?>>>(
    future: widget.repository.customers(),
    builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final rows = snap.data!.where((c) => '${c['customer_name']} ${c['phone']}'.toLowerCase().contains(_customersSearch.toLowerCase())).toList();
      return Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(12, 12, 12, 4), child: TextField(
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'بحث عن عميل بالاسم أو الهاتف', border: OutlineInputBorder()),
          onChanged: (v) => setState(() => _customersSearch = v),
        )),
        Expanded(child: rows.isEmpty
          ? _empty('لا توجد نتائج للعملاء', 'سيظهر العملاء بعد تسجيل المبيعات أو غيّر كلمات البحث')
          : ListView(padding: const EdgeInsets.all(12), children: [
              for (final c in rows) Card(child: ListTile(
                leading: const Icon(Icons.person_outline, color: Color(0xFFFFD779)),
                title: Text('${c['customer_name']}'),
                subtitle: Text('${c['phone']} • ${c['sales_count']} اشتراك\nالمشتريات: ${_money(c['total'])} • الخصومات: ${_money(c['discounts'])}\nالمحصل: ${_money(c['paid'])} • المديونية: ${_money(c['debt'])}', style: const TextStyle(height: 1.5)),
                isThreeLine: true,
                trailing: IconButton(tooltip: 'تذكير واتساب بالمديونية', icon: const Icon(Icons.chat, color: Color(0xFF42C77A)), onPressed: () => _sendCustomerDebtWhatsApp(c)),
              )),
            ])),
      ]);
    },
  );

  Widget _mainLinesPage() => FutureBuilder<List<Map<String,Object?>>>(future: widget.repository.mainLines(), builder: (context, snap) {
    if (!snap.hasData) return const Center(child:CircularProgressIndicator());
    final rows=snap.data!;
    if(rows.isEmpty) return _empty('لا توجد خطوط أم مسجلة','أضف الخط الأم وسعته وتكلفته لمتابعة المخزون');
    return ListView(padding:const EdgeInsets.all(12),children:[
      for(final r in rows) ...[
        Builder(builder:(context){ final cap=(r['total_gb'] as num).toDouble(); final used=(r['used_gb'] as num).toDouble(); final mins=(r['total_minutes'] as num).toDouble(); final usedM=(r['used_minutes'] as num).toDouble();
          return Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Row(children:[Expanded(child:Text('${r['name']}',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16))),PopupMenuButton<String>(onSelected:(v){if(v=='edit')_editMainLine(row:r);if(v=='delete')_confirmDelete('حذف الخط الأم؟',()async{await widget.repository.deleteMainLine(r['id'] as int);if(mounted)setState((){});_refresh();});},itemBuilder:(_)=>const[PopupMenuItem(value:'edit',child:Text('تعديل')),PopupMenuItem(value:'delete',child:Text('حذف'))])]),
            Text('تاريخ الشحن: ${r['start_date']??'-'}  •  التجديد: ${r['renew_date']??'-'}'),const SizedBox(height:8),
            Text('الجيجات: ${used.toStringAsFixed(1)} مستخدم / ${cap.toStringAsFixed(1)} إجمالي / ${(cap-used).toStringAsFixed(1)} متبقي'),LinearProgressIndicator(value:cap<=0?0:(used/cap).clamp(0,1)),
            const SizedBox(height:6),Text('الدقائق: ${(mins-usedM).toStringAsFixed(0)} متبقية من ${mins.toStringAsFixed(0)}'),Text('التكلفة: ${_money(r['cost'])}',style:const TextStyle(color:Color(0xFFFFD779))),
            if((r['notes']??'').toString().isNotEmpty) Text('${r['notes']}',style:const TextStyle(color:Colors.white60)),
          ])));})
      ]
    ]);
  });

  Widget _expensesPage() => FutureBuilder<List<List<Map<String,Object?>>>>(
    future: Future.wait([widget.repository.expenses(), widget.repository.mainLines()]),
    builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final expenses = snap.data![0];
      final lines = snap.data![1];
      if (expenses.isEmpty && lines.isEmpty) {
        return _empty('لا توجد مصروفات أو خطوط أم', 'أضف الخط الأم أو سجّل أي مصروف إضافي لمتابعة رصيد الخزينة');
      }
      final extraTotal = expenses.fold<double>(0, (a, r) => a + (r['amount'] as num).toDouble());
      final linesTotal = lines.fold<double>(0, (a, r) => a + (r['cost'] as num).toDouble());
      final children = <Widget>[
        Card(child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(children: [
            _summaryRow('تكلفة شحن الخطوط الأم', _money(linesTotal)),
            _summaryRow('المصروفات الإضافية', _money(extraTotal)),
            const Divider(),
            _summaryRow('إجمالي المصروفات', _money(linesTotal + extraTotal), highlight: true),
          ]),
        )),
      ];
      if (lines.isNotEmpty) {
        children.add(const Padding(
          padding: EdgeInsets.fromLTRB(4, 14, 4, 4),
          child: Text('تكاليف الخطوط الأم', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFFFD779))),
        ));
      }
      for (final r in lines) {
        children.add(Card(child: ListTile(
          leading: const Icon(Icons.sim_card, color: Color(0xFFFFD779)),
          title: Text('شحن خط أم: ${r['name']}'),
          subtitle: Text('${r['start_date'] ?? '-'} • ${r['total_gb']} GB • ${r['total_minutes']} دقيقة\n${r['notes'] ?? ''}', style: const TextStyle(height: 1.5)),
          isThreeLine: true,
          trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(_money(r['cost']), style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFFFD779))),
            PopupMenuButton<String>(
              onSelected: (v) { if (v == 'edit') _editMainLine(row: r); },
              itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('تعديل الخط الأم'))],
            ),
          ]),
        )));
      }
      if (expenses.isNotEmpty) {
        children.add(const Padding(
          padding: EdgeInsets.fromLTRB(4, 14, 4, 4),
          child: Text('المصروفات الإضافية', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFFFD779))),
        ));
      }
      for (final r in expenses) {
        children.add(Card(child: ListTile(
          leading: Text(_money(r['amount'])),
          title: Text('${r['description']}'),
          subtitle: Text('${r['expense_date']} • كمية ${r['quantity']} • ${r['gb']} جيجا\n${r['notes'] ?? ''}'),
          isThreeLine: true,
          trailing: PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'edit') _editExpense(row: r);
              if (v == 'delete') _confirmDelete('حذف المصروف؟', () async {
                await widget.repository.deleteExpense(r['id'] as int);
                if (mounted) setState(() {});
                _refresh();
              });
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'edit', child: Text('تعديل')),
              PopupMenuItem(value: 'delete', child: Text('حذف')),
            ],
          ),
        )));
      }
      return ListView(padding: const EdgeInsets.all(12), children: children);
    },
  );

  Widget _summaryRow(String label,String value,{bool highlight=false})=>Padding(padding:const EdgeInsets.symmetric(vertical:4),child:Row(children:[Expanded(child:Text(label,style:TextStyle(color:highlight?const Color(0xFFFFD779):Colors.white70,fontWeight:highlight?FontWeight.bold:FontWeight.normal))),Text(value,style:TextStyle(color:highlight?const Color(0xFFFFD779):Colors.white,fontWeight:FontWeight.bold))]));

  Widget _packagesPage() => FutureBuilder<List<Map<String,Object?>>>(future:widget.repository.packages(),builder:(context,snap){
    if(!snap.hasData)return const Center(child:CircularProgressIndicator()); final rows=snap.data!;
    return ListView(padding:const EdgeInsets.all(12),children:[for(final r in rows) Card(child:ListTile(title:Text('${r['name']}'),subtitle:Text('${r['gb']} جيجا • ${r['minutes']} دقيقة • التكلفة ${_money(r['cost'])}'),trailing:PopupMenuButton<String>(onSelected:(v){if(v=='edit')_editPackage(row:r);if(v=='archive')_confirmDelete('إخفاء الباقة من قائمة البيع؟',()async{await widget.repository.archivePackage(r['id'] as int);if(mounted)setState((){});});},itemBuilder:(_)=>const[PopupMenuItem(value:'edit',child:Text('تعديل')),PopupMenuItem(value:'archive',child:Text('إخفاء'))]),leading:Text(_money(r['price']))))]);
  });

  Widget _reportsPage() {
    final parts = _reportMonth.split('-');
    final year = int.parse(parts[0]); final month = int.parse(parts[1]);
    final period = ReportPeriod.cycle16(year:year, month:month);
    return FutureBuilder<Map<String,Object?>>(future:widget.repository.cycleReport(year:year, month:month),builder:(context,snap){
      if(!snap.hasData)return const Center(child:CircularProgressIndicator()); final r=snap.data!;
      final cards=[('قيمة المبيعات',r['sold']),('إجمالي الخصومات',r['discounts']),('المحصل خلال الدورة',r['collected']),('مديونية المبيعات',r['debt']),('إجمالي ديون العملاء',r['allDebt']),('تكلفة المبيعات',r['salesCost']),('ربح المبيعات',r['salesProfit']),('المصروفات',r['spent']),('صافي بعد المصروفات',r['netAfterSpent']),('الجيجات المباعة',r['soldGb'])];
      final salesRows=(r['salesRows'] as List).cast<Map<String,Object?>>();
      final options = List<String>.generate(13, (i) { final d=DateTime(DateTime.now().year, DateTime.now().month-i, 1); return '${d.year.toString().padLeft(4,'0')}-${d.month.toString().padLeft(2,'0')}'; });
      return ListView(padding:const EdgeInsets.all(12),children:[
        const Text('تقرير دورة الحسابات',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:Color(0xFFFFD779))),
        const SizedBox(height:8),
        DropdownButtonFormField<String>(value:_reportMonth,decoration:const InputDecoration(labelText:'شهر بداية الدورة (من يوم 16 إلى يوم 15)'),items:[for(final m in options)DropdownMenuItem(value:m,child:Text(m))],onChanged:(v){if(v!=null)setState(()=>_reportMonth=v);}),
        const SizedBox(height:8),Text('الفترة: ${period.start} إلى ${period.end}',style:const TextStyle(color:Colors.white70)),
        const SizedBox(height:10),
        GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,childAspectRatio:1.8,children:[for(final c in cards)Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[Text(c.$1,style:const TextStyle(color:Colors.white70)),const SizedBox(height:8),Text(c.$2 is num && c.$1.contains('جيجا')?'${(c.$2 as num).toStringAsFixed(1)} GB':_money(c.$2),style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold,color:Color(0xFFFFD779)))]))) ]),
        const Padding(padding:EdgeInsets.fromLTRB(4,18,4,6),child:Text('تفاصيل المبيعات خلال الدورة',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold,color:Color(0xFFFFD779)))),
        if(salesRows.isEmpty)_empty('لا توجد مبيعات في هذه الدورة','سيظهر هنا كل بيع تم تفعيله بين تاريخي بداية ونهاية الدورة'),
        for(final row in salesRows)Card(child:ListTile(title:Text('${row['customer_name']}'),subtitle:Text('${row['activation_date']} • ${row['gb']} جيجا\nالسعر: ${_money(row['price'])} • المحصل: ${_money(row['paid'])} • المتبقي: ${_money(row['remaining'])}',style:const TextStyle(height:1.4)),isThreeLine:true)),
      ]);
    });
  }

  Future<void> _editMainLine({Map<String,Object?>? row}) async {
    final name=TextEditingController(text:'${row?['name']??''}'), gb=TextEditingController(text:'${row?['total_gb']??204}'), mins=TextEditingController(text:'${row?['total_minutes']??4000}'), cost=TextEditingController(text:'${row?['cost']??1700}'), notes=TextEditingController(text:'${row?['notes']??''}');
    final date=TextEditingController(text:'${row?['start_date']??_today()}'), renew=TextEditingController(text:'${row?['renew_date']??DateTime.now().add(const Duration(days:30)).toIso8601String().substring(0,10)}');
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:Text(row==null?'إضافة خط أم':'تعديل الخط الأم'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[_field(name,'اسم / رقم الخط الأم'),_field(date,'تاريخ الشحن YYYY-MM-DD'),_field(renew,'تاريخ التجديد YYYY-MM-DD'),_field(gb,'إجمالي الجيجات',number:true),_field(mins,'إجمالي الدقائق',number:true),_field(cost,'تكلفة الشحن',number:true),_field(notes,'ملاحظات')])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('حفظ'))]));
    if(ok!=true)return; if(name.text.trim().isEmpty)return;
    await widget.repository.saveMainLine({'name':name.text.trim(),'start_date':date.text,'renew_date':renew.text,'total_gb':double.tryParse(gb.text)??0,'total_minutes':int.tryParse(mins.text)??0,'cost':double.tryParse(cost.text)??0,'notes':notes.text},id:row?['id'] as int?); if(mounted){setState((){});_refresh();}
  }

  Future<void> _editExpense({Map<String,Object?>? row}) async {
    final desc=TextEditingController(text:'${row?['description']??''}'), date=TextEditingController(text:'${row?['expense_date']??_today()}'), qty=TextEditingController(text:'${row?['quantity']??1}'), gb=TextEditingController(text:'${row?['gb']??0}'), amount=TextEditingController(text:'${row?['amount']??0}'), notes=TextEditingController(text:'${row?['notes']??''}');
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:Text(row==null?'إضافة مصروف':'تعديل مصروف'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[_field(desc,'البيان'),_field(date,'التاريخ YYYY-MM-DD'),_field(qty,'الكمية',number:true),_field(gb,'إجمالي الجيجات',number:true),_field(amount,'المبلغ بالجنيه',number:true),_field(notes,'ملاحظات')])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('حفظ'))]));
    if(ok!=true||desc.text.trim().isEmpty)return; await widget.repository.saveExpense({'code':'EXP-${row?['id']??'NEW'}','expense_date':date.text,'description':desc.text.trim(),'quantity':double.tryParse(qty.text)??1,'gb':double.tryParse(gb.text)??0,'amount':double.tryParse(amount.text)??0,'notes':notes.text},id:row?['id'] as int?); if(mounted){setState((){});_refresh();}
  }

  Future<void> _editPackage({Map<String,Object?>? row}) async {
    final name=TextEditingController(text:'${row?['name']??''}'), gb=TextEditingController(text:'${row?['gb']??0}'), mins=TextEditingController(text:'${row?['minutes']??0}'), cost=TextEditingController(text:'${row?['cost']??0}'), price=TextEditingController(text:'${row?['price']??0}');
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:Text(row==null?'إضافة باقة':'تعديل باقة'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[_field(name,'اسم الباقة'),_field(gb,'الجيجات',number:true),_field(mins,'الدقائق',number:true),_field(cost,'التكلفة',number:true),_field(price,'سعر البيع',number:true)])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('حفظ'))]));
    if(ok!=true||name.text.trim().isEmpty)return; await widget.repository.savePackage({'name':name.text.trim(),'gb':double.tryParse(gb.text)??0,'minutes':int.tryParse(mins.text)??0,'cost':double.tryParse(cost.text)??0,'price':double.tryParse(price.text)??0,'active':1},id:row?['id'] as int?); if(mounted)setState((){});
  }

  Widget _field(TextEditingController c,String label,{bool number=false})=>Padding(padding:const EdgeInsets.only(bottom:8),child:TextField(controller:c,keyboardType:number?const TextInputType.numberWithOptions(decimal:true):TextInputType.text,decoration:InputDecoration(labelText:label,border:const OutlineInputBorder())));

  Widget _paymentsPage() => Column(children:[
    Padding(padding:const EdgeInsets.all(12),child:SegmentedButton<int>(segments:const [ButtonSegment(value:0,label:Text('المديونيات'),icon:Icon(Icons.account_balance_wallet)),ButtonSegment(value:1,label:Text('سجل التحصيلات'),icon:Icon(Icons.history))],selected:{_paymentView},onSelectionChanged:(v)=>setState(()=>_paymentView=v.first))),
    Expanded(child:_paymentView==0
      ? FutureBuilder<List<Map<String,Object?>>>(future:widget.repository.sales(),builder:(context,snap){
          if(!snap.hasData)return const Center(child:CircularProgressIndicator());
          final debt=snap.data!.where((r)=>(r['remaining'] as num).toDouble()>0).toList();
          if(debt.isEmpty)return _empty('لا توجد مديونيات','كل المبيعات المسجلة مسددة أو لا توجد مبيعات');
          return ListView(padding:const EdgeInsets.all(12),children:[for(final r in debt)Card(child:ListTile(title:Text('${r['customer_name']}'),subtitle:Text('${r['phone']} • إجمالي ${_money(r['price'])} • مدفوع ${_money(r['paid'])}'),trailing:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(_money(r['remaining']),style:const TextStyle(color:Colors.orangeAccent,fontWeight:FontWeight.bold)),TextButton(onPressed:()=>_addPayment(r),child:const Text('تحصيل'))]))) ]);
        })
      : FutureBuilder<List<List<Map<String,Object?>>>>(future:Future.wait([widget.repository.paymentHistory(),widget.repository.bookingPaymentHistory()]),builder:(context,snap){
          if(!snap.hasData)return const Center(child:CircularProgressIndicator());
          final rows=[...snap.data![0],...snap.data![1]]..sort((a,b)=>'${b['payment_date']}'.compareTo('${a['payment_date']}'));
          if(rows.isEmpty)return _empty('لا توجد تحصيلات مسجلة','ستظهر هنا دفعات المبيعات ومقدمات الحجوزات');
          return ListView(padding:const EdgeInsets.all(12),children:[for(final r in rows)Card(child:ListTile(leading:Icon(r['record_type']=='booking'?Icons.bookmark:Icons.payments,color:const Color(0xFFFFD779)),title:Text('${r['customer_name']} • ${_money(r['amount'])}'),subtitle:Text('${r['payment_date']} • ${r['method']} • ${r['record_type']=='booking'?'دفعة حجز':'تحصيل بيع'}\n${r['phone']}'),isThreeLine:true,trailing:IconButton(tooltip:'حذف الدفعة',icon:const Icon(Icons.delete_outline,color:Colors.redAccent),onPressed:()=>_confirmDelete('حذف سجل التحصيل؟',()async{if(r['record_type']=='booking'){await widget.repository.deleteBookingPayment(r['id'] as int);}else{await widget.repository.deletePayment(r['id'] as int);}if(mounted){setState((){});_refresh();}}))))]);
        }))
  ]);

  Widget _renewalsPage() => FutureBuilder<List<Map<String,Object?>>>(
    future: widget.repository.sales(),
    builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final today = DateTime.now();
      final allRows = snap.data!.where((r) => (r['expiry_date'] ?? '').toString().isNotEmpty).toList()
        ..sort((a, b) => '${a['expiry_date']}'.compareTo('${b['expiry_date']}'));
      final rows = allRows.where((r) {
        final exp = DateTime.tryParse('${r['expiry_date']}');
        if (exp == null) return false;
        final days = DateTime(exp.year, exp.month, exp.day).difference(DateTime(today.year, today.month, today.day)).inDays;
        if (_renewalFilter == 1) return days >= 0 && days <= 7;
        if (_renewalFilter == 2) return days < 0;
        return true;
      }).toList();
      return Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: SegmentedButton<int>(
          segments: const [
            ButtonSegment(value: 0, label: Text('الكل')),
            ButtonSegment(value: 1, label: Text('خلال 7 أيام')),
            ButtonSegment(value: 2, label: Text('منتهية')),
          ],
          selected: {_renewalFilter},
          onSelectionChanged: (v) => setState(() => _renewalFilter = v.first),
        )),
        Expanded(child: rows.isEmpty
          ? _empty('لا توجد اشتراكات في هذا التصنيف', 'يمكنك تغيير فلتر التجديدات لعرض اشتراكات أخرى')
          : ListView(padding: const EdgeInsets.all(12), children: [
              for (final r in rows) Builder(builder: (context) {
                final exp = DateTime.tryParse('${r['expiry_date']}')!;
                final days = DateTime(exp.year, exp.month, exp.day).difference(DateTime(today.year, today.month, today.day)).inDays;
                final label = days < 0 ? 'منتهٍ منذ ${days.abs()} يوم' : days == 0 ? 'ينتهي اليوم' : 'باقي $days يوم';
                return Card(child: ListTile(
                  title: Text('${r['customer_name']}'),
                  subtitle: Text('${r['phone']} • انتهاء ${r['expiry_date']} • $label\nالمتبقي عليه: ${_money(r['remaining'])}'),
                  isThreeLine: true,
                  trailing: Wrap(spacing: 4, children: [
                    IconButton(tooltip: 'تذكير واتساب بالتجديد', onPressed: () => _sendSaleWhatsApp(r, 'renew'), icon: const Icon(Icons.chat, color: Color(0xFF42C77A))),
                    TextButton(onPressed: () async {
                      final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
                        title: const Text('تأكيد التجديد'),
                        content: Text('إنشاء اشتراك جديد بنفس بيانات ${r['customer_name']} لمدة 30 يومًا من اليوم؟'),
                        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تجديد'))],
                      ));
                      if (ok == true) {
                        try { await widget.repository.renewSale(r['id'] as int, today: _today()); if (mounted) { setState(() {}); _refresh(); } }
                        catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر التجديد: $e'))); }
                      }
                    }, child: const Text('تجديد 30 يوم')),
                  ]),
                ));
              }),
            ])),
      ]);
    },
  );

  Widget _settingsPage() => ListView(padding:const EdgeInsets.all(16),children:[
    const Text('النسخ الاحتياطي والاستعادة',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:Color(0xFFFFD779))),
    const SizedBox(height:8),const Text('يحتوي ملف النسخة على الباقات والخطوط والمبيعات والحجوزات وسجلات التحصيل والمصروفات والإعدادات.'),
    const SizedBox(height:16),FilledButton.icon(onPressed:_exportExcel,icon:const Icon(Icons.table_chart),label:const Text('تصدير ملف Excel للمبيعات والحجوزات')) ,
    const SizedBox(height:10),FilledButton.icon(onPressed:_exportBackup,icon:const Icon(Icons.backup),label:const Text('إنشاء ومشاركة نسخة احتياطية')),
    const SizedBox(height:10),OutlinedButton.icon(onPressed:_restoreBackup,icon:const Icon(Icons.restore),label:const Text('استعادة نسخة احتياطية JSON')),
    const SizedBox(height:18),const Card(child:Padding(padding:EdgeInsets.all(14),child:Text('تنبيه: الاستعادة تستبدل بيانات التطبيق الحالية بالكامل. تأكد من الاحتفاظ بنسخة حديثة قبل الاستعادة.',style:TextStyle(height:1.6,color:Colors.orangeAccent)))),
  ]);

  Future<void> _exportExcel() async {
    try {
      final sales=await widget.repository.sales();
      final bookings=await widget.repository.bookings();
      final expenses=await widget.repository.expenses();
      final lines=await widget.repository.mainLines();
      final packages=await widget.repository.packages();
      final customers=await widget.repository.customers();
      final payments=await widget.repository.paymentHistory();
      final bookingPayments=await widget.repository.bookingPaymentHistory();
      final book=Excel.createExcel();
      book.rename('Sheet1','المبيعات');
      void addSheet(String name,List<String> headers,List<List<CellValue>> rows){
        final sheet=book[name];
        sheet.appendRow(headers.map((v)=>TextCellValue(v)).toList());
        for(final row in rows){sheet.appendRow(row);}
      }
      CellValue txt(Object? v)=>TextCellValue('${v??''}');
      CellValue num(Object? v)=>DoubleCellValue((v as num?)?.toDouble()??0);
      final saleRows=<List<CellValue>>[];
      for(final r in sales){saleRows.add([num(r['id']),txt(r['customer_name']),txt(r['phone']),num(r['gb']),num(r['minutes']),txt(r['activation_date']),num(r['original_price']),num(r['discount']),num(r['price']),num(r['cost']),num((r['price'] as num)-(r['cost'] as num)),num(r['paid']),num(r['remaining']),txt(r['notes'])]);}
      addSheet('المبيعات',['رقم العملية','اسم العميل','الهاتف','الجيجا','الدقائق','التفعيل','السعر الأصلي','الخصم','السعر النهائي','التكلفة','الربح','المدفوع','المتبقي','ملاحظات'],saleRows);
      final paymentRows=<List<CellValue>>[];
      for(final r in payments){paymentRows.add([num(r['id']),num(r['sale_id']),txt(r['customer_name']),txt(r['phone']),num(r['amount']),txt(r['payment_date']),txt(r['method']),txt(r['notes'])]);}
      addSheet('سجل التحصيلات',['رقم الدفعة','رقم البيع','اسم العميل','الهاتف','المبلغ','تاريخ التحصيل','طريقة الدفع','ملاحظات'],paymentRows);
      final bookingPaymentRows=<List<CellValue>>[];
      for(final r in bookingPayments){bookingPaymentRows.add([num(r['id']),num(r['booking_id']),txt(r['customer_name']),txt(r['phone']),num(r['amount']),txt(r['payment_date']),txt(r['method'])]);}
      addSheet('دفعات الحجوزات',['رقم الدفعة','رقم الحجز','اسم العميل','الهاتف','المبلغ','تاريخ الدفعة','طريقة الدفع'],bookingPaymentRows);
      final bookingRows=<List<CellValue>>[];
      for(final r in bookings){bookingRows.add([num(r['id']),txt(r['customer_name']),txt(r['phone']),num(r['gb']),txt(r['booking_date']),txt(r['activation_date']),txt(r['expiry_date']),num(r['price']),num(r['paid']),num(r['remaining']),txt(r['notes'])]);}
      addSheet('الحجوزات',['رقم الحجز','اسم العميل','الهاتف','الجيجا','تاريخ الحجز','التفعيل','الانتهاء','السعر','المدفوع','المتبقي','ملاحظات'],bookingRows);
      final expenseRows=<List<CellValue>>[];
      for(final r in expenses){expenseRows.add([num(r['id']),txt(r['expense_date']),txt(r['description']),num(r['quantity']),num(r['gb']),num(r['amount']),txt(r['notes'])]);}
      addSheet('المصروفات',['الرقم','التاريخ','البيان','الكمية','الجيجا','المبلغ','ملاحظات'],expenseRows);
      final lineRows=<List<CellValue>>[];
      for(final r in lines){lineRows.add([num(r['id']),txt(r['name']),txt(r['start_date']),txt(r['renew_date']),num(r['total_gb']),num(r['used_gb']),num((r['total_gb'] as num)-(r['used_gb'] as num)),num(r['total_minutes']),num(r['used_minutes']),num(r['cost'])]);}
      addSheet('الخطوط الأم',['الرقم','اسم الخط','تاريخ الشحن','التجديد','إجمالي الجيجا','المستخدم','المتبقي','إجمالي الدقائق','المستخدم دقائق','التكلفة'],lineRows);
      final packageRows=<List<CellValue>>[];
      for(final r in packages){packageRows.add([num(r['id']),txt(r['name']),num(r['gb']),num(r['minutes']),num(r['cost']),num(r['price'])]);}
      addSheet('الباقات',['الرقم','اسم الباقة','الجيجا','الدقائق','التكلفة','سعر البيع'],packageRows);
      final customerRows=<List<CellValue>>[];
      for(final r in customers){customerRows.add([txt(r['customer_name']),txt(r['phone']),num(r['sales_count']),num(r['total']),num(r['discounts']),num(r['paid']),num(r['debt'])]);}
      addSheet('العملاء',['اسم العميل','الهاتف','عدد الاشتراكات','إجمالي المشتريات','الخصومات','المحصل','المديونية'],customerRows);
      final bytes=book.encode();
      if(bytes==null)throw StateError('تعذر إنشاء ملف Excel');
      final dir=await getTemporaryDirectory();
      final file=File('${dir.path}/QUPTAN_WE_EGYPT_${_today()}.xlsx');
      await file.writeAsBytes(bytes,flush:true);
      await Share.shareXFiles([XFile(file.path)],text:'تقرير بيانات QUPTAN WE EGYPT PRO');
    } catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر تصدير Excel: $e')));}
  }

  String _normalizeEgyptPhone(String raw){
    final western=raw.replaceAllMapped(RegExp(r'[٠-٩۰-۹]'),(m){
      final code=m[0]!.codeUnitAt(0);
      final offset=code>=0x0660&&code<=0x0669?0x0660:0x06F0;
      return String.fromCharCode(0x30+code-offset);
    });
    var phone=western.replaceAll(RegExp(r'\D'),'');
    if(phone.startsWith('00'))phone=phone.substring(2);
    if(RegExp(r'^01[0125]\d{8}$').hasMatch(phone))return '2$phone';
    if(RegExp(r'^1[0125]\d{8}$').hasMatch(phone))return '20$phone';
    if(RegExp(r'^201[0125]\d{8}$').hasMatch(phone))return phone;
    return phone;
  }

  Future<void> _sendSaleWhatsApp(Map<String,Object?> sale,String type) async {
    final phone=_normalizeEgyptPhone('${sale['phone']??''}');
    if(phone.length<10){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('رقم هاتف العميل غير صالح لإرسال واتساب')));return;}
    final name='${sale['customer_name']??'عميلنا العزيز'}';
    final packageId=sale['package_id'];
    final packages=await widget.repository.packages();
    Map<String,Object?>? package;
    for(final p in packages){if(p['id']==packageId){package=p;break;}}
    final packageName='${package?['name']??'باقة WE'}';
    final remaining=(sale['remaining'] as num?)?.toDouble()??0;
    final expiry='${sale['expiry_date']??'غير محدد'}';
    final message=type=='debt'
      ? 'أهلاً بك يا أستاذ $name من القبطان لخدمات الباقات والإنترنت 👑\nتذكير لطيف بخصوص باقة $packageName.\nإجمالي الباقة: ${sale['price']} جنيه\nالمدفوع: ${sale['paid']} جنيه\nالمتبقي: $remaining جنيه\nنشكرك على ثقتك بنا 💜'
      : 'أهلاً بك يا أستاذ $name من القبطان لخدمات الباقات والإنترنت 👑\nنود تذكيرك بأن باقتك $packageName ستنتهي بتاريخ $expiry.\nهل ترغب في تجديد الباقة لضمان استمرار الخدمة بدون انقطاع؟ 💜';
    final uri=Uri.parse('https://wa.me/$phone?text=${Uri.encodeComponent(message)}');
    try { final opened=await launchUrl(uri,mode:LaunchMode.externalApplication); if(!opened&&mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تعذر فتح واتساب على الجهاز'))); }
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر فتح واتساب: $e')));}
  }

  Future<void> _sendCustomerDebtWhatsApp(Map<String,Object?> customer) async {
    final phone=_normalizeEgyptPhone('${customer['phone']??''}');
    if(phone.length<10){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('رقم هاتف العميل غير صالح لإرسال واتساب')));return;}
    final debt=(customer['debt'] as num?)?.toDouble()??0;
    final name='${customer['customer_name']??'عميلنا العزيز'}';
    final message='أهلاً بك يا أستاذ $name من القبطان لخدمات الباقات والإنترنت 👑\n'
      'تذكير لطيف بخصوص إجمالي المديونية على اشتراكاتك.\n'
      'إجمالي المشتريات: ${customer['total']} جنيه\n'
      'إجمالي المدفوع: ${customer['paid']} جنيه\n'
      'المتبقي: $debt جنيه\nنشكرك على ثقتك بنا 💜';
    final uri=Uri.parse('https://wa.me/$phone?text=${Uri.encodeComponent(message)}');
    try{final opened=await launchUrl(uri,mode:LaunchMode.externalApplication);if(!opened&&mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تعذر فتح واتساب على الجهاز')));}
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر فتح واتساب: $e')));}
  }

  Future<void> _sendActivationWhatsApp(Map<String,Object?> sale) async {
    final phone=_normalizeEgyptPhone('${sale['phone']??''}');
    if(!RegExp(r'^20?1[0125]\d{8,9}$').hasMatch(phone)){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('رقم هاتف العميل غير صالح لإرسال واتساب')));
      return;
    }
    final packages=await widget.repository.packages();
    Map<String,Object?>? package;
    for(final p in packages){if(p['id']==sale['package_id']){package=p;break;}}
    final name='${sale['customer_name']??'عميلنا العزيز'}';
    final message='أهلاً بك يا أستاذ $name في القبطان لخدمات الباقات والإنترنت 👑\n'
      'تم تفعيل باقتك بنجاح:\n'
      '📦 الباقة: ${package?['name']??'باقة WE'}\n'
      '📅 تاريخ التفعيل: ${sale['activation_date']??'-'}\n'
      '⏳ تاريخ الانتهاء: ${sale['expiry_date']??'-'}\n'
      '💰 المطلوب: ${sale['price']} جنيه\n'
      '✅ المدفوع: ${sale['paid']} جنيه\n'
      '${(sale['remaining'] as num? ?? 0)>0?'⚠️ المتبقي: ${sale['remaining']} جنيه\n':'✨ خالص السداد بالكامل\n'}'
      'شكرًا لثقتك بنا 💜';
    final uri=Uri.parse('https://wa.me/$phone?text=${Uri.encodeComponent(message)}');
    try{final opened=await launchUrl(uri,mode:LaunchMode.externalApplication);if(!opened&&mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تعذر فتح واتساب على الجهاز')));}
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر فتح واتساب: $e')));}
  }

  Future<void> _exportBackup() async {
    try {
      final json=await widget.repository.exportBackupJson();
      final dir=await getTemporaryDirectory();
      final file=File('${dir.path}/QUPTAN_Backup_${_today()}.json');
      await file.writeAsString(json,flush:true);
      await Share.shareXFiles([XFile(file.path)],text:'نسخة احتياطية من QUPTAN WE EGYPT PRO');
    } catch(e) { if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر إنشاء النسخة: $e'))); }
  }

  Future<void> _restoreBackup() async {
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('تأكيد الاستعادة'),content:const Text('سيتم استبدال كل البيانات الحالية بمحتويات النسخة المختارة. هل أنشأت نسخة من بياناتك الحالية؟'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('متابعة'))]));
    if(ok!=true)return;
    try {
      final picked=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['json'],withData:true);
      if(picked==null||picked.files.single.bytes==null)return;
      await widget.repository.restoreBackupJson(utf8.decode(picked.files.single.bytes!));
      if(mounted){setState((){});_refresh();ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تمت استعادة النسخة الاحتياطية')));}
    } catch(e) { if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('فشلت الاستعادة: $e'))); }
  }

  Future<void> _showInvoice(Map<String,Object?> sale) async {
    final key=GlobalKey();
    final packageRows=await widget.repository.packages();
    Map<String,Object?>? package;
    for(final p in packageRows){if(p['id']==sale['package_id']){package=p;break;}}
    if(!mounted)return;
    await showDialog<void>(context:context,builder:(ctx)=>Dialog(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:430,maxHeight:700),child:Column(mainAxisSize:MainAxisSize.min,children:[
      Flexible(child:SingleChildScrollView(child:RepaintBoundary(key:key,child:Container(width:(MediaQuery.of(ctx).size.width-80).clamp(260,380).toDouble(),padding:const EdgeInsets.all(22),color:Colors.white,child:DefaultTextStyle(style:const TextStyle(color:Color(0xFF21152E),fontSize:14),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        const Center(child:Text('القبطان',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900,color:Color(0xFF5A2A83)))),
        const Center(child:Text('QUPTAN WE EGYPT',style:TextStyle(fontSize:12,fontWeight:FontWeight.bold,color:Color(0xFFB28A35)))),
        const Divider(color:Color(0xFFB28A35),thickness:2,height:26),
        const Center(child:Text('فاتورة بيع / تجديد',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold))),
        const SizedBox(height:12),
        _invoiceRow('رقم الفاتورة','${sale['id']}'),_invoiceRow('التاريخ','${sale['sale_date']??_today()}'),_invoiceRow('اسم العميل','${sale['customer_name']}'),_invoiceRow('رقم الهاتف','${sale['phone']}'),
        const Divider(height:22),_invoiceRow('الباقة','${package?['name']??'باقة مخصصة'}'),_invoiceRow('السعة','${sale['gb']} جيجا'),_invoiceRow('تاريخ التفعيل','${sale['activation_date']??'-'}'),_invoiceRow('تاريخ الانتهاء','${sale['expiry_date']??'-'}'),
        const Divider(height:22),if(((sale['discount'] as num?)??0)>0)...[_invoiceRow('السعر الأصلي','${_money(sale['original_price'])}'),_invoiceRow('الخصم','${_money(sale['discount'])}')],_invoiceRow('السعر النهائي','${_money(sale['price'])}'),_invoiceRow('المدفوع','${_money(sale['paid'])}'),_invoiceRow('المتبقي','${_money(sale['remaining'])}'),
        const Divider(height:22),const Center(child:Text('شكرًا لثقتكم في القبطان 👑',style:TextStyle(fontWeight:FontWeight.bold,color:Color(0xFF5A2A83)))),const SizedBox(height:6),const Center(child:Text('للتواصل: 01514166575 - 01003024330',style:TextStyle(fontSize:11))),
      ])))))),
      Padding(padding:const EdgeInsets.all(10),child:Wrap(alignment:WrapAlignment.center,spacing:8,children:[OutlinedButton.icon(onPressed:()async{await _shareInvoiceImage(key,sale['id']);},icon:const Icon(Icons.image),label:const Text('مشاركة صورة')),FilledButton.icon(onPressed:()async{await _shareInvoicePdf(key,sale['id']);},icon:const Icon(Icons.picture_as_pdf),label:const Text('مشاركة PDF')),TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إغلاق'))]))
    ]))));
  }

  Widget _invoiceRow(String label,String value)=>Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Row(children:[Expanded(child:Text(label,style:const TextStyle(color:Color(0xFF665B70)))),Expanded(flex:2,child:Text(value,textAlign:TextAlign.left,style:const TextStyle(fontWeight:FontWeight.bold)))]));

  Future<Uint8List> _captureInvoice(GlobalKey key) async {
    await WidgetsBinding.instance.endOfFrame;
    final object=key.currentContext?.findRenderObject();
    if(object is! RenderRepaintBoundary)throw StateError('تعذر تجهيز صورة الفاتورة');
    final image=await object.toImage(pixelRatio:3);
    final data=await image.toByteData(format:ui.ImageByteFormat.png);
    image.dispose();
    if(data==null)throw StateError('تعذر تحويل الفاتورة إلى صورة');
    return data.buffer.asUint8List();
  }

  Future<void> _shareInvoiceImage(GlobalKey key,Object? id) async {
    try{final bytes=await _captureInvoice(key);final dir=await getTemporaryDirectory();final file=File('${dir.path}/QUPTAN_invoice_$id.png');await file.writeAsBytes(bytes,flush:true);await Share.shareXFiles([XFile(file.path)],text:'فاتورة القبطان رقم $id');}
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر إنشاء صورة الفاتورة: $e')));}
  }

  Future<void> _shareInvoicePdf(GlobalKey key,Object? id) async {
    try{final bytes=await _captureInvoice(key);final doc=pw.Document();final image=pw.MemoryImage(bytes);doc.addPage(pw.Page(pageFormat:pdf.PdfPageFormat.a4,build:(ctx)=>pw.Center(child:pw.Image(image,width:pdf.PdfPageFormat.a4.width-40,height:pdf.PdfPageFormat.a4.height-40,fit:pw.BoxFit.contain))));final dir=await getTemporaryDirectory();final file=File('${dir.path}/QUPTAN_invoice_$id.pdf');await file.writeAsBytes(await doc.save(),flush:true);await Share.shareXFiles([XFile(file.path)],text:'فاتورة القبطان رقم $id');}
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر إنشاء PDF: $e')));}
  }

  Widget _empty(String title, String hint) => Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.inbox_outlined, size: 48, color: Color(0xFFFFD779)), const SizedBox(height: 12), Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text(hint, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70))])));
  String _money(Object? v) => '${((v as num?) ?? 0).toStringAsFixed(0)} ج';
  String _today() { final d = DateTime.now(); return '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}'; }
  String _next16() { final d=DateTime.now(); final target=DateTime(d.year,d.month,16); final actual=d.day<=16?target:DateTime(d.year,d.month+1,16); return '${actual.year.toString().padLeft(4,'0')}-${actual.month.toString().padLeft(2,'0')}-${actual.day.toString().padLeft(2,'0')}'; }

  Future<void> _distributeBookings() async {
    try {
      final count=await widget.repository.distributeBookingsSmart();
      final lines=await widget.repository.mainLines();
      final bookings=await widget.repository.bookings();
      if(!mounted)return;
      if(lines.isEmpty||bookings.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('أضف حجوزات وخطوطًا أم أولًا لإجراء التوزيع')));return;}
      setState((){});
      await showDialog<void>(context:context,builder:(ctx)=>AlertDialog(title:const Text('ملخص التوزيع الذكي'),content:SizedBox(width:420,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        Text('تم تحديث توزيع $count حجزًا. التوزيع تنازليًا حسب الجيجا، وبحد أقصى 6 حجوزات لكل خط عادي.'),
        const SizedBox(height:12),
        for(final line in lines) Builder(builder:(context){final assigned=bookings.where((b)=>b['line_id']==line['id']).toList();final used=assigned.fold<double>(0,(sum,b)=>sum+(b['gb'] as num).toDouble());return Card(child:Padding(padding:const EdgeInsets.all(10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${line['name']}',style:const TextStyle(fontWeight:FontWeight.bold,color:Color(0xFFFFD779))),Text('الحجوزات: ${assigned.length} • السعة: ${used.toStringAsFixed(1)} / ${(line['total_gb'] as num).toStringAsFixed(1)} GB'),Text(assigned.isEmpty?'لا توجد حجوزات مسندة':assigned.map((b)=>'${b['customer_name']} (${b['gb']} GB)').join('، '),style:const TextStyle(fontSize:12))])));}),
      ]))),actions:[FilledButton(onPressed:()=>Navigator.pop(ctx),child:const Text('تم'))]));
    } catch(e) { if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر توزيع الحجوزات: $e'))); }
  }

  Future<void> _addSale() async => _saleOrBooking(isBooking: false);
  Future<void> _addBooking() async => _saleOrBooking(isBooking: true);
  Future<void> _saleOrBooking({required bool isBooking}) async {
    final name = TextEditingController(); final phone = TextEditingController(); final discount = TextEditingController(text: '0'); final payment = TextEditingController(text: '0'); final notes = TextEditingController();
    final packages = await widget.repository.packages(); final lines = await widget.repository.mainLines(); if (!mounted || packages.isEmpty) return;
    int packageId = packages.first['id'] as int; int lineChoice = -1; String method = 'إنستاباي';
    final ok = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setDialog) {
      final pkg = packages.firstWhere((p) => p['id'] == packageId); final price = ((pkg['price'] as num).toDouble() - (double.tryParse(discount.text) ?? 0)).clamp(0, double.infinity).toDouble();
      return AlertDialog(title: Text(isBooking ? 'إضافة حجز جديد' : 'تسجيل بيع جديد'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم العميل')),
        TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف')),
        const SizedBox(height: 8), DropdownButtonFormField<int>(value: packageId, isExpanded: true, decoration: const InputDecoration(labelText: 'الباقة'), items: [for (final p in packages) DropdownMenuItem(value: p['id'] as int, child: Text('${p['name']} — ${_money(p['price'])}'))], onChanged: (v) { if (v != null) setDialog(() => packageId = v); }),
        if (lines.isNotEmpty) DropdownButtonFormField<int>(value: lineChoice, isExpanded:true, decoration:const InputDecoration(labelText:'الخط الأم (اختياري)'), items:[const DropdownMenuItem(value:-1,child:Text('بدون تحديد')),for(final l in lines) DropdownMenuItem(value:l['id'] as int,child:Text('${l['name']} • ${l['total_gb']} GB'))], onChanged:(v){if(v!=null)setDialog(()=>lineChoice=v);}),
        TextField(controller: discount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الخصم بالجنيه'), onChanged: (_) => setDialog(() {})),
        Align(alignment: Alignment.centerRight, child: Padding(padding: const EdgeInsets.only(top: 10), child: Text('السعر النهائي: ${price.toStringAsFixed(0)} ج', style: const TextStyle(color: Color(0xFFFFD779), fontWeight: FontWeight.bold)))),
        TextField(controller: payment, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: isBooking ? 'مقدم الحجز (اختياري)' : 'المبلغ المدفوع الآن')),
        DropdownButtonFormField<String>(value: method, decoration: const InputDecoration(labelText: 'طريقة الدفع'), items: const [DropdownMenuItem(value: 'إنستاباي', child: Text('إنستاباي')), DropdownMenuItem(value: 'محفظة', child: Text('محفظة')), DropdownMenuItem(value: 'نقدي', child: Text('نقدي'))], onChanged: (v) { if (v != null) method = v; }),
        TextField(controller: notes, decoration: const InputDecoration(labelText: 'ملاحظات')),
      ])), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () { final paid = double.tryParse(payment.text) ?? 0; if (name.text.trim().isEmpty || phone.text.trim().isEmpty || (double.tryParse(discount.text) ?? -1) < 0 || paid < 0 || paid > price || (price <= 0)) { ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('راجع الاسم والهاتف والخصم والمدفوع'))); return; } Navigator.pop(ctx, true); }, child: const Text('حفظ'))]);
    }));
    if (ok != true || !mounted) return;
    final p = packages.firstWhere((x) => x['id'] == packageId); final finalPrice = ((p['price'] as num).toDouble() - (double.tryParse(discount.text) ?? 0)).clamp(0, double.infinity).toDouble();
    final data = <String, Object?>{'customer_name': name.text.trim(), 'phone': phone.text.trim(), 'package_id': packageId, 'line_id': lineChoice == -1 ? null : lineChoice, 'gb': p['gb'], 'minutes': p['minutes'], 'cost': p['cost'], 'original_price': p['price'], 'discount': double.tryParse(discount.text) ?? 0, 'price': finalPrice, 'payment_method': method, 'notes': notes.text.trim()};
    try {
      if (isBooking) {
        final activation = _next16();
        final expiry = DateTime.parse(activation).add(const Duration(days:30)).toIso8601String().substring(0,10);
        final deposit = double.tryParse(payment.text) ?? 0;
        await widget.repository.createBooking({...data, 'booking_date': _today(), 'activation_date': activation, 'expiry_date': expiry},initialPayment:deposit,paymentDate:_today(),method:method);
        await widget.repository.promoteDueBookings(today:_today());
      } else {
        await widget.repository.createSale({...data, 'sale_date': _today(), 'activation_date': _today(), 'expiry_date': DateTime.now().add(const Duration(days: 30)).toIso8601String().substring(0, 10)}, initialPayment: double.tryParse(payment.text) ?? 0, paymentDate: _today(), method: method);
      }
      if (!mounted) return; setState(() {}); _refresh(); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(isBooking ? 'تم حفظ الحجز' : 'تم تسجيل البيع')));
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر الحفظ: $e'))); }
  }

  Future<void> _editSale(Map<String,Object?> sale) async {
    final name=TextEditingController(text:'${sale['customer_name']??''}');
    final phone=TextEditingController(text:'${sale['phone']??''}');
    final price=TextEditingController(text:'${sale['price']??0}');
    final original=TextEditingController(text:'${sale['original_price']??sale['price']??0}');
    final discount=TextEditingController(text:'${sale['discount']??0}');
    final cost=TextEditingController(text:'${sale['cost']??0}');
    final gb=TextEditingController(text:'${sale['gb']??0}');
    final minutes=TextEditingController(text:'${sale['minutes']??0}');
    final activation=TextEditingController(text:'${sale['activation_date']??_today()}');
    final expiry=TextEditingController(text:'${sale['expiry_date']??''}');
    final notes=TextEditingController(text:'${sale['notes']??''}');
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('تعديل بيانات البيع'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[_field(name,'اسم العميل'),_field(phone,'رقم الهاتف'),_field(gb,'عدد الجيجا',number:true),_field(minutes,'عدد الدقائق',number:true),_field(original,'السعر الأصلي',number:true),_field(discount,'الخصم',number:true),_field(price,'السعر النهائي بعد الخصم',number:true),_field(cost,'التكلفة',number:true),_field(activation,'تاريخ التفعيل YYYY-MM-DD'),_field(expiry,'تاريخ الانتهاء YYYY-MM-DD'),_field(notes,'ملاحظات')])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('حفظ'))]));
    if(ok!=true||name.text.trim().isEmpty||phone.text.trim().isEmpty)return;
    try { await widget.repository.updateSale(sale['id'] as int,{'customer_name':name.text.trim(),'phone':phone.text.trim(),'gb':double.parse(gb.text),'minutes':int.parse(minutes.text),'original_price':double.parse(original.text),'discount':double.parse(discount.text),'price':double.parse(price.text),'cost':double.parse(cost.text),'activation_date':activation.text,'expiry_date':expiry.text,'notes':notes.text}); if(mounted){setState((){});_refresh();} }
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر تعديل البيع: $e')));}
  }

  Future<void> _editBooking(Map<String,Object?> booking) async {
    final name=TextEditingController(text:'${booking['customer_name']??''}');
    final phone=TextEditingController(text:'${booking['phone']??''}');
    final price=TextEditingController(text:'${booking['price']??0}');
    final original=TextEditingController(text:'${booking['original_price']??booking['price']??0}');
    final discount=TextEditingController(text:'${booking['discount']??0}');
    final cost=TextEditingController(text:'${booking['cost']??0}');
    final gb=TextEditingController(text:'${booking['gb']??0}');
    final minutes=TextEditingController(text:'${booking['minutes']??0}');
    final activation=TextEditingController(text:'${booking['activation_date']??_next16()}');
    final expiry=TextEditingController(text:'${booking['expiry_date']??''}');
    final notes=TextEditingController(text:'${booking['notes']??''}');
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('تعديل بيانات الحجز'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[_field(name,'اسم العميل'),_field(phone,'رقم الهاتف'),_field(gb,'عدد الجيجا',number:true),_field(minutes,'عدد الدقائق',number:true),_field(original,'السعر الأصلي',number:true),_field(discount,'الخصم',number:true),_field(price,'السعر النهائي بعد الخصم',number:true),_field(cost,'التكلفة',number:true),_field(activation,'تاريخ التفعيل YYYY-MM-DD'),_field(expiry,'تاريخ الانتهاء YYYY-MM-DD'),_field(notes,'ملاحظات')])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('حفظ'))]));
    if(ok!=true||name.text.trim().isEmpty||phone.text.trim().isEmpty)return;
    try { await widget.repository.updateBooking(booking['id'] as int,{'customer_name':name.text.trim(),'phone':phone.text.trim(),'gb':double.parse(gb.text),'minutes':int.parse(minutes.text),'original_price':double.parse(original.text),'discount':double.parse(discount.text),'price':double.parse(price.text),'cost':double.parse(cost.text),'activation_date':activation.text,'expiry_date':expiry.text,'notes':notes.text}); await widget.repository.promoteDueBookings(today:_today()); if(mounted){setState((){});_refresh();} }
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر تعديل الحجز: $e')));}
  }

  Future<void> _addBookingPayment(Map<String, Object?> booking) async {
    final amount = TextEditingController(); final date=TextEditingController(text:_today()); String method = 'إنستاباي';
    final ok = await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:Text('دفعة حجز ${booking['customer_name']}'),content:Column(mainAxisSize:MainAxisSize.min,children:[Text('المتبقي: ${_money(booking['remaining'])}'),TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'مبلغ الدفعة')),_field(date,'تاريخ الدفعة YYYY-MM-DD'),DropdownButtonFormField<String>(value:method,items:const[DropdownMenuItem(value:'إنستاباي',child:Text('إنستاباي')),DropdownMenuItem(value:'محفظة',child:Text('محفظة')),DropdownMenuItem(value:'نقدي',child:Text('نقدي'))],onChanged:(v){if(v!=null)method=v;})]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('تسجيل الدفعة'))]));
    if(ok!=true)return;
    try { await widget.repository.addBookingPayment(bookingId:booking['id'] as int,amount:double.parse(amount.text),date:date.text,method:method); if(mounted){setState((){});_refresh();} }
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر تسجيل دفعة الحجز: $e')));}
  }

  Future<void> _addPayment(Map<String, Object?> sale) async {
    final amount = TextEditingController(); final date=TextEditingController(text:_today()); String method = 'إنستاباي';
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: Text('تحصيل من ${sale['customer_name']}'), content: Column(mainAxisSize: MainAxisSize.min, children: [Text('المتبقي: ${_money(sale['remaining'])}'), TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'مبلغ التحصيل')), _field(date,'تاريخ التحصيل YYYY-MM-DD'), DropdownButtonFormField<String>(value: method, items: const [DropdownMenuItem(value: 'إنستاباي', child: Text('إنستاباي')), DropdownMenuItem(value: 'محفظة', child: Text('محفظة')), DropdownMenuItem(value: 'نقدي', child: Text('نقدي'))], onChanged: (v) { if (v != null) method = v; })]), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تسجيل'))]));
    if (ok != true) return; try { await widget.repository.addPayment(saleId: sale['id'] as int, amount: double.parse(amount.text), date: date.text, method: method); if (mounted) { setState(() {}); _refresh(); } } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تسجيل التحصيل: $e'))); }
  }

  Future<void> _confirmDelete(String title, Future<void> Function() action) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: Text(title), content: const Text('لا يمكن التراجع عن هذه العملية.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تأكيد الحذف'))]));
    if (ok == true) {
      try { await action(); if (mounted) setState(() {}); }
      catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تنفيذ العملية: $e'))); }
    }
  }
}
