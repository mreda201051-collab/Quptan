/// Reporting periods used by the original Quptan WE Egypt workflow.
/// The 16-to-15 cycle is inclusive at both ends.
class ReportPeriod {
  const ReportPeriod({required this.start, required this.end});
  final String start;
  final String end;

  static ReportPeriod cycle16({required int year, required int month}) {
    if (month < 1 || month > 12) throw ArgumentError.value(month, 'month');
    final nextYear = month == 12 ? year + 1 : year;
    final nextMonth = month == 12 ? 1 : month + 1;
    return ReportPeriod(
      start: _date(year, month, 16),
      end: _date(nextYear, nextMonth, 15),
    );
  }

  static ReportPeriod calendarMonth({required int year, required int month}) {
    if (month < 1 || month > 12) throw ArgumentError.value(month, 'month');
    final lastDay = DateTime(year, month + 1, 0).day;
    return ReportPeriod(
      start: _date(year, month, 1),
      end: _date(year, month, lastDay),
    );
  }

  static String _date(int year, int month, int day) =>
      '${year.toString().padLeft(4, '0')}-${month.toString().padLeft(2, '0')}-${day.toString().padLeft(2, '0')}';
}

/// Returns the reference month for the active 16th-to-15th cycle.
/// Before the 16th, the active cycle began in the previous month.
String defaultCycleReferenceMonth(DateTime now) {
  var year = now.year;
  var month = now.month;
  if (now.day < 16) {
    month--;
    if (month == 0) {
      month = 12;
      year--;
    }
  }
  return '${year.toString().padLeft(4, '0')}-${month.toString().padLeft(2, '0')}';
}
