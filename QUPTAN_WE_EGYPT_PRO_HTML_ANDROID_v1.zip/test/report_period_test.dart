import 'package:flutter_test/flutter_test.dart';
import 'package:quptan_we_egypt_pro/domain/report_period.dart';

void main() {
  group('ReportPeriod', () {
    test('16th cycle ends on the 15th of the following month', () {
      final period = ReportPeriod.cycle16(year: 2026, month: 8);
      expect(period.start, '2026-08-16');
      expect(period.end, '2026-09-15');
    });

    test('16th cycle crosses the year boundary', () {
      final period = ReportPeriod.cycle16(year: 2026, month: 12);
      expect(period.start, '2026-12-16');
      expect(period.end, '2027-01-15');
    });

    test('calendar month uses its actual last day', () {
      final period = ReportPeriod.calendarMonth(year: 2028, month: 2);
      expect(period.start, '2028-02-01');
      expect(period.end, '2028-02-29');
    });

    test('active reference month changes on the 16th', () {
      expect(defaultCycleReferenceMonth(DateTime(2026, 11, 15)), '2026-10');
      expect(defaultCycleReferenceMonth(DateTime(2026, 11, 16)), '2026-11');
      expect(defaultCycleReferenceMonth(DateTime(2026, 1, 1)), '2025-12');
    });
    test('rejects an invalid reference month', () {
      expect(() => ReportPeriod.cycle16(year: 2026, month: 13), throwsArgumentError);
    });
  });
}
