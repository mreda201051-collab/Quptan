#!/usr/bin/env bash
set -euo pipefail
flutter create . --platforms=android --org com.quptan.weegypt
flutter pub get
flutter analyze
flutter test
flutter build apk --release
