class SaleSnapshot {
  const SaleSnapshot({required this.price, required this.cost, required this.gb, required this.payments});
  final double price, cost, gb;
  final List<double> payments;
  double get paid => payments.fold(0, (a, b) => a + b);
  double get remaining => (price - paid).clamp(0, double.infinity).toDouble();
  double get profit => price - cost;
}

class FinancialTotals {
  const FinancialTotals({required this.sales, required this.cost, required this.collected, required this.debt, required this.expenses, required this.soldGb, required this.stockGb});
  final double sales, cost, collected, debt, expenses, soldGb, stockGb;
  double get netSalesProfit => sales - cost;
  double get cashBalance => collected - expenses;
  double get leftGb => stockGb - soldGb;
}

FinancialTotals calculateTotals({required List<SaleSnapshot> sales, required double mainLineCosts, required double otherExpenses, required double stockGb}) {
  final sold = sales.fold<double>(0, (a, s) => a + s.price);
  final cost = sales.fold<double>(0, (a, s) => a + s.cost);
  final collected = sales.fold<double>(0, (a, s) => a + s.paid);
  final debt = sales.fold<double>(0, (a, s) => a + s.remaining);
  final soldGb = sales.fold<double>(0, (a, s) => a + s.gb);
  return FinancialTotals(sales: sold, cost: cost, collected: collected, debt: debt, expenses: mainLineCosts + otherExpenses, soldGb: soldGb, stockGb: stockGb);
}
