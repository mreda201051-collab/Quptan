import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:file_picker/file_picker.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const QuptanApp());
}

class QuptanApp extends StatelessWidget {
  const QuptanApp({super.key});


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'القبطان برو - QUPTAN PRO',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF071426),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFE7BD58),
          secondary: Color(0xFF2F8FE5),
        ),
      ),
      home: const QuptanWebViewPage(),
    );
  }
}

class QuptanWebViewPage extends StatefulWidget {
  const QuptanWebViewPage({super.key});

  @override
  State<QuptanWebViewPage> createState() => _QuptanWebViewPageState();
}

class _QuptanWebViewPageState extends State<QuptanWebViewPage> {
  late final WebViewController _controller;
  bool _loading = true;
  String? _error;

  Future<void> _handleBackupMessage(JavaScriptMessage message) async {
    try {
      final request = jsonDecode(message.message) as Map<String, dynamic>;
      final action = request['action'];
      if (action == 'export') {
        final payload = request['payload'];
        if (payload == null) throw Exception('بيانات النسخة الاحتياطية غير موجودة');
        final bytes = Uint8List.fromList(utf8.encode(const JsonEncoder.withIndent('  ').convert(payload)));
        final stamp = DateTime.now().toIso8601String().replaceAll(':', '-').split('.').first;
        final path = await FilePicker.platform.saveFile(
          dialogTitle: 'حفظ نسخة القبطان الاحتياطية',
          fileName: 'QUPTAN_PRO_BACKUP_$stamp.json',
          type: FileType.custom,
          allowedExtensions: ['json'],
          bytes: bytes,
        );
        if (path != null && mounted) {
          await _controller.runJavaScript("setLocalBackupStatus('تم إنشاء النسخة المحلية: $stamp'); showToast('تم إنشاء النسخة الاحتياطية');");
        }
      } else if (action == 'import') {
        final result = await FilePicker.platform.pickFiles(
          dialogTitle: 'اختيار نسخة القبطان الاحتياطية',
          type: FileType.custom,
          allowedExtensions: ['json'],
          withData: true,
          allowMultiple: false,
        );
        if (result != null && result.files.single.bytes != null && mounted) {
          final content = utf8.decode(result.files.single.bytes!);
          final encoded = jsonEncode(content);
          await _controller.runJavaScript('importBackupFromNative($encoded);');
        }
      }
    } catch (error) {
      if (mounted) {
        final safe = jsonEncode('تعذر تنفيذ النسخ الاحتياطي: $error');
        await _controller.runJavaScript("showToast($safe);");
      }
    }
  }


  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('QuptanBackup', onMessageReceived: _handleBackupMessage)
      ..setBackgroundColor(const Color(0xFF071426))
      ..enableZoom(false)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            if (mounted) setState(() => _loading = true);
          },
          onPageFinished: (_) {
            if (mounted) setState(() {
              _loading = false;
              _error = null;
            });
          },
          onWebResourceError: (error) {
            if (error.isForMainFrame == true && mounted) {
              setState(() {
                _loading = false;
                _error = error.description;
              });
            }
          },
          onNavigationRequest: (request) {
            final uri = Uri.tryParse(request.url);
            if (uri == null) return NavigationDecision.prevent;
            final scheme = uri.scheme.toLowerCase();
            if (scheme == 'tel' || scheme == 'mailto' || scheme == 'whatsapp' ||
                (scheme == 'https' && (uri.host == 'wa.me' || uri.host == 'api.whatsapp.com'))) {
              unawaited(launchUrl(uri, mode: LaunchMode.externalApplication));
              return NavigationDecision.prevent;
            }
            if (scheme == 'http' || scheme == 'https') {
              unawaited(launchUrl(uri, mode: LaunchMode.externalApplication));
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadFlutterAsset('assets/index.html');
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (!didPop && await _controller.canGoBack()) {
          await _controller.goBack();
        } else if (!didPop) {
          await SystemNavigator.pop();
        }
      },
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              WebViewWidget(controller: _controller),
              if (_loading)
                const Align(
                  alignment: Alignment.topCenter,
                  child: LinearProgressIndicator(
                    minHeight: 2,
                    color: Color(0xFFE7BD58),
                    backgroundColor: Color(0xFF142C49),
                  ),
                ),
              if (_error != null)
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.error_outline, color: Color(0xFFE7BD58), size: 42),
                        const SizedBox(height: 12),
                        const Text('تعذر فتح واجهة القبطان'),
                        const SizedBox(height: 8),
                        Text(_error!, textAlign: TextAlign.center),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: () {
                            setState(() {
                              _error = null;
                              _loading = true;
                            });
                            _controller.loadFlutterAsset('assets/index.html');
                          },
                          child: const Text('إعادة المحاولة'),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
