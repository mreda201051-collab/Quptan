# سجل التغييرات

## 0.4.0-dev — 2026-11-25
- إضافة تعديل بيانات المبيعات والحجوزات مع حماية الدفعات المسجلة.
- إضافة دفعات الحجز وعرض المدفوع والمتبقي في شاشة الحجوزات.
- إضافة الترحيل التلقائي للحجوزات المستحقة عند بدء التطبيق.
- جعل تاريخ التفعيل الافتراضي للحجز أقرب يوم 16.
- إضافة تقرير دورة 16 إلى 15 مع اختيار الشهر المرجعي.
- إضافة اختبارات وحدة لفترات التقرير.
- إضافة تصدير Excel متعدد الأوراق للمبيعات والحجوزات والدفعات والمصروفات والخطوط والباقات.
- إضافة رسائل WhatsApp لتذكير المديونية والتجديد.
- إضافة GitHub Actions لبناء APK سحابيًا من الهاتف.
- لم يتم تشغيل Flutter analyze أو flutter test أو بناء APK لعدم توفر Flutter/Android SDK في بيئة التطوير.

## 0.3.0 — المصدر الأصلي
- إدارة الخطوط الأم والمصروفات والباقات والنسخ الاحتياطي.
- توسيع إدارة الحجوزات والتقارير الأساسية.


## 0.4.1-dev
- Added shareable sale invoice rendered by Flutter as PNG and PDF to preserve Arabic shaping.
- Added activation confirmation message for WhatsApp.
- Added payment-history view for sales and booking deposits, including safe deletion of individual payment records.
- Customer aggregation now follows the original HTML rule: group by phone when available, otherwise by customer name; displays purchases, discounts, collected, and debt.
- Added customer-level WhatsApp debt reminder and improved smart-booking distribution summary.
- Added original price and discount columns to the sales Excel export.
- Flutter analysis, tests, and Android build remain pending because the local environment has no Flutter/Android toolchain.
