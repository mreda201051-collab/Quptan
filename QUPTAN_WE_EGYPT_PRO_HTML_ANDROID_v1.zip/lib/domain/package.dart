class Package {
  const Package({required this.id, required this.name, required this.gb, required this.minutes, required this.cost, required this.price});
  final int id; final String name; final double gb; final int minutes; final double cost; final double price;
  factory Package.fromMap(Map<String, Object?> m) => Package(id: m['id'] as int, name: m['name'] as String, gb: (m['gb'] as num).toDouble(), minutes: m['minutes'] as int, cost: (m['cost'] as num).toDouble(), price: (m['price'] as num).toDouble());
  Map<String, Object?> toMap() => {'id':id,'name':name,'gb':gb,'minutes':minutes,'cost':cost,'price':price};
}
