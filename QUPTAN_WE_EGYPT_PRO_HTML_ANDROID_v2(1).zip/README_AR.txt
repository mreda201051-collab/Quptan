QUPTAN WE EGYPT PRO - Android WebView source

هذا المشروع يضع ملف HTML الأصلي داخل تطبيق Android باستخدام WebView.
- الصفحة الرئيسية: assets/index.html
- نقطة تشغيل Flutter: lib/main.dart
- التخزين المحلي في الصفحة يعتمد على localStorage في WebView.

مهم:
1) هذا مصدر المشروع وليس APK جاهزًا.
2) يلزم بناء APK من GitHub Actions بعد رفع المشروع.
3) مكتبة SheetJS في ملف HTML الأصلي محملة حاليًا من CDN؛ لذلك وظيفة Excel قد تحتاج إنترنت ما لم تُضمّن المكتبة محليًا.
4) يلزم اختبار النسخ الاحتياطي/الاستعادة والتنزيل على جهاز Android قبل اعتبار التطبيق نهائيًا.
